import React, { useEffect, useState } from 'react';
import apiClient from '../../api/client';
import { useCollaborateLists } from '../CollaborateData';
import { mapApiError, describeError, isCanceled } from '../apiErrors';
import ProposalForm from '../ProposalForm';
import SearchableSelect from '../SearchableSelect';
import { Note, showError } from '../fields';

/**
 * Record that an existing block helps with an existing challenge.
 *
 * POST /api/proposals/challenge-blocks   { challenge, block }
 *
 * ── ALSO A RELATIONSHIP, ALSO LIVE IMMEDIATELY ───────────────────────────────
 * Like "Support a connection", this creates an edge — (Challenge)-[:SOLVED_BY]->
 * (Block) — and an edge has no review status. Verified: the pairing shows up on
 * GET /api/challenges/:name to an anonymous reader straight away, and never
 * appears in GET /api/proposals/mine.
 *
 * The consolation is that both ends are already approved content, so nothing
 * unreviewed becomes visible — only a claim about how two approved things
 * relate. That is a much smaller thing than the reference case, but it is still
 * not review, and the form says so.
 *
 * ── THE EXISTING PAIRINGS ARE FETCHED PER CHALLENGE ──────────────────────────
 * GET /api/challenges/:name returns the blocks already recorded against it —
 * 48 pairings across 14 challenges. That is a small request made once per
 * challenge chosen, which is cheaper and simpler than pulling every pairing up
 * front for a form where only one challenge is ever in play.
 *
 * MERGE means proposing an existing pairing is accepted silently rather than
 * rejected, so the API will NOT catch this one — the check here is the only one
 * there is.
 */

const ERROR_PATTERNS = [
    { test: /^No challenge named /, field: 'challenge' },
    { test: /^No block named /, field: 'block' },
];

const ChallengeBlockForm = () => {
    const { challenges, blocks, graphLoading, graphError, loading, error: metadataError } =
        useCollaborateLists({ graph: true });

    const [challenge, setChallenge] = useState(null);
    const [block, setBlock] = useState(null);
    const [errors, setErrors] = useState({});
    const [formError, setFormError] = useState(null);
    const [submitting, setSubmitting] = useState(false);
    const [success, setSuccess] = useState(null);

    // The blocks already recorded against the chosen challenge.
    const [existing, setExisting] = useState({ names: [], loading: false, error: null });

    useEffect(() => {
        if (!challenge) {
            setExisting({ names: [], loading: false, error: null });
            return undefined;
        }
        const controller = new AbortController();
        let active = true;
        setExisting({ names: [], loading: true, error: null });

        apiClient
            .get(`/api/challenges/${encodeURIComponent(challenge.name)}`, { signal: controller.signal })
            .then((response) => {
                if (!active) return;
                setExisting({
                    names: (response.data?.blocks || []).map((entry) => entry.name),
                    loading: false,
                    error: null,
                });
            })
            .catch((err) => {
                if (!active || isCanceled(err)) return;
                // Not fatal: the pairing check is a courtesy, and MERGE makes a
                // duplicate harmless. Say so rather than blocking the form.
                setExisting({ names: [], loading: false, error: describeError(err) });
            });

        return () => { active = false; controller.abort(); };
    }, [challenge]);

    const alreadyPaired = Boolean(block && existing.names.includes(block.name));

    const validate = () => {
        const next = {};
        if (!challenge) next.challenge = 'Choose the challenge.';
        if (!block) next.block = 'Choose the block that helps with it.';
        if (alreadyPaired) {
            next.block = `“${block.name}” is already recorded against “${challenge.name}”.`;
        }
        return next;
    };

    const canSubmit = Object.keys(validate()).length === 0
        && !loading && !graphLoading && !existing.loading;

    const submit = async () => {
        const found = validate();
        setErrors(found);
        if (Object.keys(found).length > 0) return;

        setSubmitting(true);
        setFormError(null);
        try {
            const response = await apiClient.post('/api/proposals/challenge-blocks', {
                challenge: challenge.name,
                block: block.name,
            });
            const row = response.data?.challenge_block || {};
            setSuccess({
                label: row.item || `${challenge.name} → ${block.name}`,
                description: `“${block.name}” is now listed among the blocks that address `
                    + `“${challenge.name}”, and will be marked when that challenge is selected on the map.`,
                reviewed: false,
            });
            // Keep the challenge selected — recording several blocks against one
            // challenge in a row is the normal way this form gets used.
            setExisting((prev) => ({ ...prev, names: [...prev.names, block.name] }));
            setBlock(null);
        } catch (err) {
            const { field, message } = mapApiError(err, { patterns: ERROR_PATTERNS });
            if (field) setErrors((prev) => ({ ...prev, [field]: message }));
            else setFormError(message);
        } finally {
            setSubmitting(false);
        }
    };

    const reset = () => {
        setErrors({});
        setFormError(null);
        setSuccess(null);
    };

    const challengeMeta = (entry) => {
        const count = entry.block_count;
        if (typeof count !== 'number') return '';
        return count === 0 ? 'no blocks yet' : `${count} block${count === 1 ? '' : 's'}`;
    };

    return (
        <ProposalForm
            title="Address a challenge"
            lede="Record that a block on the map helps with one of the industrial challenges. Both have to be on the map already."
            onSubmit={submit}
            canSubmit={canSubmit}
            submitting={submitting}
            submitLabel="Record the pairing"
            busyLabel="Recording…"
            submitNote="This one is not reviewed — see the note above."
            formError={formError || metadataError || graphError}
            success={success}
            onSubmitAnother={reset}
        >
            <Note tone="warn">
                <p>
                    <strong>This takes effect immediately.</strong> The pairing is a relationship
                    between two things already approved, and relationships carry no review status —
                    so there is no pending state, it will not appear in your submissions, and it
                    cannot be withdrawn from here.
                </p>
            </Note>

            <SearchableSelect
                label="Challenge"
                required
                wide
                items={challenges}
                value={challenge}
                onChange={(entry) => {
                    setChallenge(entry);
                    setErrors((prev) => ({ ...prev, challenge: undefined, block: undefined }));
                    setFormError(null);
                }}
                getKey={(entry) => entry.name}
                getLabel={(entry) => entry.name}
                getMeta={challengeMeta}
                getSearchText={(entry) => `${entry.name} ${entry.description || ''}`}
                loading={loading}
                placeholder="Search the challenges…"
                error={errors.challenge}
                hint="Searchable by description as well as name."
            />

            {challenge && (
                <Note tone="info">
                    <p>“{challenge.description}”</p>
                    {existing.loading && <p>Checking what is already recorded…</p>}
                    {existing.error && (
                        <p>
                            Could not read the blocks already recorded against this challenge
                            ({existing.error}), so the duplicate check below is unavailable.
                            Recording a pairing twice is harmless — the second is merged into the
                            first — but it is worth checking the map afterwards.
                        </p>
                    )}
                    {!existing.loading && !existing.error && (
                        existing.names.length > 0 ? (
                            <p>
                                Already addressed by: {existing.names.join(', ')}.
                            </p>
                        ) : (
                            <p>No block is recorded against this challenge yet.</p>
                        )
                    )}
                </Note>
            )}

            <SearchableSelect
                label="Block"
                required
                wide
                items={blocks}
                value={block}
                onChange={(entry) => {
                    setBlock(entry);
                    setErrors((prev) => ({ ...prev, block: undefined }));
                    setFormError(null);
                }}
                getKey={(entry) => entry.name}
                getLabel={(entry) => entry.name}
                getMeta={(entry) => `${entry.level} · ${entry.maps.join(', ')}`}
                loading={graphLoading}
                placeholder="Search 198 blocks…"
                error={showError(errors.block, alreadyPaired
                    ? `“${block.name}” is already recorded against “${challenge.name}”.`
                    : null)}
                hint="The approach, process, method or tool that helps with this difficulty."
            />
        </ProposalForm>
    );
};

export default ChallengeBlockForm;
