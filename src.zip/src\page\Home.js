import React, { useState } from 'react';
import './Home.css';
import { useNavigate } from 'react-router-dom';
import Navbar from '../Components/Navbar/Navbar';
import GraphVisualization from '../Components/GraphVisualization/GraphVisualization';
import { useAuth } from '../auth/AuthContext';

/**
 * The map, and the shell around it.
 *
 * PUBLIC. Reading the cartographies needs no account, so nothing here waits on
 * the session and nothing is hidden while it loads — the graph starts fetching
 * immediately and the navbar fills its account slot when /api/auth/me answers.
 *
 * The six legacy CRUD screens (AddNodeForm, AddReferenceForm, ReviewableNodes,
 * ReviewReferences, DeleteOption, UpdateNode) used to be mounted here. They call
 * routes that no longer exist and are being replaced rather than repaired, so
 * they are no longer imported — importing them would bundle broken code and pull
 * their global CSS into every page. The files are left untouched on disk.
 */
const Home = () => {
    const navigate = useNavigate();
    const { user, loading, signOut } = useAuth();
    const [activeForm, setActiveForm] = useState('graph');

    const handleLogout = async () => {
        await signOut();
        // Stay on the map: signing out of a public page should not eject the
        // reader from the thing they were reading.
        setActiveForm('graph');
    };

    return (
        <div className="app-shell">
            <Navbar
                setActiveForm={setActiveForm}
                activeForm={activeForm}
                user={user}
                loading={loading}
                onSignIn={() => navigate('/login')}
                onRegister={() => navigate('/signup')}
                // Its own route, not a view of Home — RequireAuth sends a
                // signed-out visitor to sign in and back here afterwards, so the
                // bar offers it to everyone rather than hiding it.
                onCollaborate={() => navigate('/collaborate')}
                onReview={() => navigate('/review')}
                onLogout={handleLogout}
            />
            <div className="app-shell-view">
                {activeForm === 'home' && <h1>Welcome to DynaCart</h1>}
                {activeForm === 'graph' && <GraphVisualization />}
            </div>
        </div>
    );
};

export default Home;
