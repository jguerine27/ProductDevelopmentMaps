import React, { useMemo, useState } from 'react';
import apiClient from '../../api/client';
import { useCollaborateLists } from '../CollaborateData';
import { mapApiError } from '../apiErrors';
import ProposalForm from '../ProposalForm';
import { TextField, TextAreaField, SelectField, CheckboxGroup, DerivedField, showError } from '../fields';

/**
 * Propose a block — a concept or technique at one of the four levels.
 *
 * POST /api/proposals/blocks
 *   { name, level, maps[], related_approach, color, citations }
 *
 * ── COLOUR IS DERIVED, NOT ASKED FOR ─────────────────────────────────────────
 * Colour is a property of the APPROACH FAMILY, not of the block: every block in
 * the Systems Engineering family carries that family's colour, and the map's
 * legend is only readable because that holds without exception. A colour picker
 * would let one contributor break the legend for every reader, and there is no
 * answer a contributor could give that is better than the one the data already
 * contains. So the swatch below is read-only and follows the chosen approach.
 *
 * The value still travels in the body, because the API stores `color` on the
 * node and a block created without one would render uncoloured.
 *
 * ── LEVELS, MAPS AND APPROACHES COME FROM /api/metadata ──────────────────────
 * None of the three is hard-coded here. `metadata.approaches` also carries each
 * family's colour and how many blocks it holds, which is what makes both the
 * derived swatch and the counts on the options possible without a second call.
 *
 * ── "agnostic from approaches" IS AN ANSWER, NOT A FALLBACK ──────────────────
 * Two thirds of the blocks on the published maps belong to no single approach
 * family, and a contributor who reads the list as "pick your family, or give up"
 * will force a block into a family it does not belong to. Rather than reorder
 * the list — which would mean hard-coding that option's name — each option shows
 * how many blocks it already holds, so the majority answer is visible as a fact
 * from the data rather than asserted in prose.
 */

const EMPTY = Object.freeze({
    name: '',
    level: '',
    related_approach: '',
    maps: [],
    citations: '',
});

/**
 * 422s this form can provoke that carry no leading quoted field name.
 * Everything else follows the backend's `"field" is …` convention and is mapped
 * by apiErrors.js without help. See services/validation.js.
 */
const ERROR_PATTERNS = [
    { test: /^A block named .* already exists/, field: 'name' },
    { test: /^Unknown map code/, field: 'maps' },
];

/** `color` is derived here, so a complaint about it is our bug, not the user's. */
const ERROR_FIELDS = { color: null };

const BlockForm = () => {
    const {
        metadata, approachColors, blocks, blocksByName, graphLoading, graphError,
        loading, error: metadataError,
    } = useCollaborateLists({ graph: true });

    const [values, setValues] = useState(EMPTY);
    const [errors, setErrors] = useState({});
    const [formError, setFormError] = useState(null);
    const [submitting, setSubmitting] = useState(false);
    const [success, setSuccess] = useState(null);

    const set = (field, value) => {
        setValues((prev) => ({ ...prev, [field]: value }));
        // Clear the field's error as soon as it is touched: leaving a stale
        // complaint under a box someone is actively fixing is just noise.
        setErrors((prev) => (prev[field] ? { ...prev, [field]: undefined } : prev));
        setFormError(null);
    };

    const toggleMap = (code) => {
        setValues((prev) => ({
            ...prev,
            maps: prev.maps.includes(code)
                ? prev.maps.filter((entry) => entry !== code)
                : [...prev.maps, code],
        }));
        setErrors((prev) => (prev.maps ? { ...prev, maps: undefined } : prev));
        setFormError(null);
    };

    const trimmedName = values.name.trim();

    /**
     * Block.name is unique and matched EXACTLY by the API, so a name differing
     * only in case is not a duplicate as far as Neo4j is concerned — but it
     * almost certainly is one as far as a reader is concerned. The two cases are
     * therefore reported differently: an exact match will be rejected and blocks
     * submission here; a case-only difference is a warning the contributor can
     * overrule, because "SysML" and "Sysml" could legitimately be two things.
     *
     * Only APPROVED blocks are visible to this check — /api/graph serves the
     * approved map. A collision with somebody else's pending block still comes
     * back as a 422, which ERROR_PATTERNS puts on this same field.
     */
    const nameClash = useMemo(() => {
        if (!trimmedName) return null;
        if (blocksByName.has(trimmedName)) return { exact: true, name: trimmedName };
        const lower = trimmedName.toLowerCase();
        const near = blocks.find((block) => block.name.toLowerCase() === lower);
        return near ? { exact: false, name: near.name } : null;
    }, [trimmedName, blocks, blocksByName]);

    const derivedColor = values.related_approach
        ? (approachColors.get(values.related_approach) || '')
        : '';

    const levelOptions = useMemo(
        () => (metadata.levels || []).map((level) => ({ value: level, label: level })),
        [metadata.levels]
    );

    const approachOptions = useMemo(
        () => (metadata.approaches || []).map((approach) => ({
            value: approach.name,
            // The count is what shows, without asserting it, that belonging to no
            // family is the ordinary case rather than a last resort.
            label: `${approach.name} — ${approach.block_count} block${approach.block_count === 1 ? '' : 's'}`,
        })),
        [metadata.approaches]
    );

    const mapOptions = useMemo(
        () => (metadata.maps || []).map((map) => ({ value: map.code, label: map.label })),
        [metadata.maps]
    );

    /** Every rule the API applies that can be checked before sending. */
    const validate = () => {
        const next = {};
        if (!trimmedName) next.name = 'Give the block a name.';
        else if (trimmedName.length > 300) next.name = `Names are capped at 300 characters (this is ${trimmedName.length}).`;
        else if (nameClash && nameClash.exact) next.name = `A block named "${trimmedName}" is already on the map.`;

        if (!values.level) next.level = 'Choose the level this block sits at.';
        if (!values.related_approach) next.related_approach = 'Choose an approach family.';
        if (values.maps.length === 0) next.maps = 'Choose at least one cartography this block belongs to.';
        if (values.citations.trim().length > 4000) next.citations = 'Citations are capped at 4000 characters.';
        return next;
    };

    // Drives the disabled state. Deliberately the same rules as validate(), so
    // the button never enables on something submit would reject.
    const canSubmit = Object.keys(validate()).length === 0 && !loading && !graphLoading;

    const submit = async () => {
        const found = validate();
        setErrors(found);
        if (Object.keys(found).length > 0) return;

        setSubmitting(true);
        setFormError(null);
        try {
            const response = await apiClient.post('/api/proposals/blocks', {
                name: trimmedName,
                level: values.level,
                maps: values.maps,
                related_approach: values.related_approach,
                color: derivedColor,
                citations: values.citations.trim(),
            });
            const proposal = response.data?.proposal || {};
            setSuccess({
                label: `Block — ${proposal.item || trimmedName}`,
                description: `A ${values.level.toLowerCase()} in ${values.maps.join(', ')}, filed under "${values.related_approach}".`,
            });
        } catch (err) {
            const { field, message } = mapApiError(err, { fields: ERROR_FIELDS, patterns: ERROR_PATTERNS });
            if (field) setErrors((prev) => ({ ...prev, [field]: message }));
            else setFormError(message);
        } finally {
            setSubmitting(false);
        }
    };

    const reset = () => {
        setValues(EMPTY);
        setErrors({});
        setFormError(null);
        setSuccess(null);
    };

    return (
        <ProposalForm
            title="Propose a block"
            lede="A block is one concept or technique on the map — an approach, a process, a method or a tool. Say what it is called, where it sits and which cartographies it belongs to."
            onSubmit={submit}
            canSubmit={canSubmit}
            submitting={submitting}
            formError={formError || metadataError || graphError}
            success={success}
            onSubmitAnother={reset}
        >
            <TextField
                label="Name"
                required
                autoFocus
                wide
                maxLength={300}
                value={values.name}
                onChange={(value) => set('name', value)}
                placeholder="e.g. Model-based systems engineering"
                error={showError(errors.name, nameClash && nameClash.exact
                    ? `A block named "${trimmedName}" is already on the map.`
                    : null)}
                warning={nameClash && !nameClash.exact
                    ? `"${nameClash.name}" is already on the map and differs only in capitalisation. If you mean the same concept, add to that block instead.`
                    : null}
                hint="The name as it should read on the map. It has to be unique across all 198 blocks."
            />

            <SelectField
                label="Level"
                required
                value={values.level}
                onChange={(value) => set('level', value)}
                options={levelOptions}
                placeholder={loading ? 'Loading…' : 'Choose a level…'}
                disabled={loading}
                error={errors.level}
                hint="Approach and Process are broad; Method and Tool are specific."
            />

            <SelectField
                label="Approach family"
                required
                value={values.related_approach}
                onChange={(value) => set('related_approach', value)}
                options={approachOptions}
                placeholder={loading ? 'Loading…' : 'Choose an approach family…'}
                disabled={loading}
                error={errors.related_approach}
                hint="Which school of thought this block belongs to. Most blocks belong to none in particular — the counts show how the existing map divides up."
            />

            <DerivedField
                label="Colour"
                empty="Choose an approach family to see the colour."
                hint="Set by the approach family, not by you: every block in a family shares its colour, which is the only reason the map's legend can be read."
            >
                {derivedColor && (
                    <>
                        <span className="pdm-collab-swatch" style={{ background: derivedColor }} aria-hidden="true" />
                        <span>{values.related_approach}</span>
                        <code>{derivedColor}</code>
                    </>
                )}
            </DerivedField>

            <CheckboxGroup
                legend="Cartographies"
                values={values.maps}
                onToggle={toggleMap}
                options={mapOptions}
                error={errors.maps}
                hint="Which published maps this block belongs on. Choose every one it applies to."
            />

            <TextAreaField
                label="Citations"
                rows={3}
                maxLength={4000}
                value={values.citations}
                onChange={(value) => set('citations', value)}
                placeholder="Bricogne, 2015; Beck et al., 2001; Tomiyama et al., 2019"
                error={errors.citations}
                hint={
                    'Semicolon-separated. These are the references printed inside the block’s own '
                    + 'box on the published figures — the sources that justify this concept belonging '
                    + 'on the map at all. They are NOT the references that support a connection between '
                    + 'two blocks: those are attached to the connection, on the "Support a connection" form.'
                }
            />
        </ProposalForm>
    );
};

export default BlockForm;
