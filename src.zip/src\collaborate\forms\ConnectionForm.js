import React, { useMemo, useState } from 'react';
import apiClient from '../../api/client';
import { useCollaborateLists, linkKey } from '../CollaborateData';
import { mapApiError } from '../apiErrors';
import ProposalForm from '../ProposalForm';
import SearchableSelect from '../SearchableSelect';
import { SelectField, CheckboxGroup, Note, showError } from '../fields';

/**
 * Propose a connection between two blocks that are already on the map.
 *
 * POST /api/proposals/links   { source, target, ltype, maps[] }
 *
 * ── THE MAP RULE IS THE WHOLE FORM ───────────────────────────────────────────
 * A link may only exist in a map where BOTH endpoint blocks exist. The API
 * enforces it (assertLinkEndpointsAndMaps), and the reason it must is that a
 * violation fails SILENTLY at read time rather than loudly: graphQuery.js drops
 * any edge whose endpoints did not survive the map filter, so a link claiming
 * map 'S' between two blocks that are not in S simply vanishes from the Smart
 * Products map with no error raised anywhere.
 *
 * So this form never offers a map that would break it. Once both endpoints are
 * chosen, the map chooser shows the INTERSECTION of their two map lists and says
 * so. It is not a validation that fires on submit — it is what the control
 * contains.
 *
 * The case that matters is the empty intersection: 8124 of the possible block
 * pairs share no map at all ("Virtual commissioning" is Mechatronics-only,
 * "Scrum CPS" is CPS-only). Submitting one of those returns a 422 quoting two
 * JSON arrays, which tells a contributor nothing they can act on. Here it is
 * blocked before submit with a sentence naming both blocks and their maps.
 *
 * ── THE ENDPOINT PICKERS SEARCH, THEY DO NOT SCROLL ──────────────────────────
 * 198 blocks is far past the point where a <select> is usable, and block names
 * are ambiguous on their own — "System modelling techniques" and "Interface
 * modelling technique" are different things at different levels — so each row
 * carries its level and its maps.
 */

/**
 * What each link type CLAIMS. `metadata.ltypes` carries the code, the short
 * label and the drawn style; it does not carry this, because it is an
 * explanation for a contributor rather than data the map renders.
 *
 * Keyed by code and looked up, never used as the list itself: the options come
 * from the API, so a fourth link type would appear here with its own label and
 * simply no extra sentence, rather than being silently dropped.
 */
const LTYPE_MEANING = {
    ec: 'The literature states this connection outright. This is the ordinary case for a connection you can cite.',
    oc: 'Drawn by the review authors to make the map readable, not because a paper asserts it.',
    h: 'One concept is derived from the other — a hybridisation of two approaches rather than a citation.',
};

const EMPTY = Object.freeze({ source: null, target: null, ltype: '', maps: [] });

/**
 * 422s this form can provoke that carry no leading quoted field name.
 * See services/validation.js — assertLinkEndpointsAndMaps and the duplicate
 * check both raise prose.
 */
const ERROR_PATTERNS = [
    { test: /^source block /, field: 'source' },
    { test: /^target block /, field: 'target' },
    { test: /^Every map on a link must be present on both endpoint blocks/, field: 'maps' },
    { test: /^Unknown map code/, field: 'maps' },
];

const ConnectionForm = () => {
    const {
        metadata, blocks, links, mapLabels, graphLoading, graphError,
        loading, error: metadataError,
    } = useCollaborateLists({ graph: true });

    const [values, setValues] = useState(EMPTY);
    const [errors, setErrors] = useState({});
    const [formError, setFormError] = useState(null);
    const [submitting, setSubmitting] = useState(false);
    const [success, setSuccess] = useState(null);

    const clearError = (field) => setErrors((prev) => (prev[field] ? { ...prev, [field]: undefined } : prev));

    /**
     * The intersection, recomputed whenever an endpoint changes.
     *
     * Also prunes any already-ticked map that the new pair does not share —
     * otherwise choosing a second block after ticking a map would leave an
     * invisible, invalid selection behind and submit it.
     */
    const setEndpoint = (which, block) => {
        setValues((prev) => {
            const next = { ...prev, [which]: block };
            const shared = intersectionOf(next.source, next.target);
            return { ...next, maps: prev.maps.filter((code) => shared.includes(code)) };
        });
        clearError(which);
        clearError('maps');
        setFormError(null);
    };

    const toggleMap = (code) => {
        setValues((prev) => ({
            ...prev,
            maps: prev.maps.includes(code)
                ? prev.maps.filter((entry) => entry !== code)
                : [...prev.maps, code],
        }));
        clearError('maps');
        setFormError(null);
    };

    const { source, target } = values;
    const bothChosen = Boolean(source && target);
    const sameBlock = bothChosen && source.name === target.name;
    const shared = useMemo(() => intersectionOf(source, target), [source, target]);
    const noSharedMap = bothChosen && !sameBlock && shared.length === 0;

    /**
     * The API keys a Link on (source, target, ltype), so the same pair may carry
     * more than one link — an `ec` and an `oc` between the same two blocks is
     * ordinary. Only the full triple is a duplicate.
     */
    const existingKeys = useMemo(() => new Set(links.map(linkKey)), [links]);
    const duplicate = bothChosen && values.ltype
        && existingKeys.has(linkKey({ source: source.name, target: target.name, ltype: values.ltype }));

    /**
     * The reverse direction is a DIFFERENT link as far as the API is concerned,
     * and there are no reverse-direction duplicates anywhere in the published
     * data — so proposing one is much more likely a slip than a claim. A warning,
     * not a block: only the contributor knows which way round they meant.
     */
    const reverseExists = bothChosen && values.ltype && !duplicate
        && existingKeys.has(linkKey({ source: target.name, target: source.name, ltype: values.ltype }));

    const ltypeOptions = useMemo(
        () => (metadata.ltypes || []).map((ltype) => ({
            value: ltype.code,
            label: `${ltype.code} — ${ltype.label}`,
        })),
        [metadata.ltypes]
    );

    const mapOptions = useMemo(
        () => shared.map((code) => ({ value: code, label: mapLabels.get(code) || code })),
        [shared, mapLabels]
    );

    const blockMeta = (block) => `${block.level} · ${block.maps.join(', ')}`;

    const validate = () => {
        const next = {};
        if (!source) next.source = 'Choose the block the connection starts from.';
        if (!target) next.target = 'Choose the block the connection points to.';
        if (sameBlock) next.target = 'A connection has to run between two different blocks.';
        if (!values.ltype) next.ltype = 'Choose what kind of connection this is.';
        if (duplicate) {
            next.ltype = `This connection already exists: "${source.name}" → "${target.name}" [${values.ltype}].`;
        }
        if (noSharedMap) {
            next.maps = 'These two blocks share no cartography, so there is no map this connection could exist in.';
        } else if (bothChosen && !sameBlock && values.maps.length === 0) {
            next.maps = 'Choose at least one cartography this connection belongs to.';
        }
        return next;
    };

    const canSubmit = Object.keys(validate()).length === 0 && !loading && !graphLoading;

    const submit = async () => {
        const found = validate();
        setErrors(found);
        if (Object.keys(found).length > 0) return;

        setSubmitting(true);
        setFormError(null);
        try {
            const response = await apiClient.post('/api/proposals/links', {
                source: source.name,
                target: target.name,
                ltype: values.ltype,
                maps: values.maps,
            });
            const proposal = response.data?.proposal || {};
            setSuccess({
                label: `Connection — ${proposal.item || `${source.name} -> ${target.name} [${values.ltype}]`}`,
                description: `Proposed in ${values.maps.map((c) => mapLabels.get(c) || c).join(' and ')}.`,
            });
        } catch (err) {
            const { field, message } = mapApiError(err, { patterns: ERROR_PATTERNS });
            if (field) setErrors((prev) => ({ ...prev, [field]: message }));
            else setFormError(message);
        } finally {
            setSubmitting(false);
        }
    };

    const reset = () => {
        setValues(EMPTY);
        setErrors({});
        setFormError(null);
        setSuccess(null);
    };

    return (
        <ProposalForm
            title="Propose a connection"
            lede="A connection is a relationship between two blocks that are already on the map. If either end is not there yet, propose the block first."
            onSubmit={submit}
            canSubmit={canSubmit}
            submitting={submitting}
            formError={formError || metadataError || graphError}
            success={success}
            onSubmitAnother={reset}
        >
            <SearchableSelect
                label="From (source)"
                required
                items={blocks}
                value={source}
                onChange={(block) => setEndpoint('source', block)}
                getKey={(block) => block.name}
                getLabel={(block) => block.name}
                getMeta={blockMeta}
                loading={graphLoading}
                placeholder="Search 198 blocks…"
                error={errors.source}
                hint="Type to filter. Each row shows the block's level and cartographies."
            />

            <SearchableSelect
                label="To (target)"
                required
                items={blocks}
                value={target}
                onChange={(block) => setEndpoint('target', block)}
                getKey={(block) => block.name}
                getLabel={(block) => block.name}
                getMeta={blockMeta}
                loading={graphLoading}
                placeholder="Search 198 blocks…"
                error={showError(errors.target, sameBlock
                    ? 'A connection has to run between two different blocks.'
                    : null)}
                hint="Direction is meaningful — the connection runs from the source to this block."
            />

            <SelectField
                label="Kind of connection"
                required
                wide
                value={values.ltype}
                onChange={(value) => { setValues((prev) => ({ ...prev, ltype: value })); clearError('ltype'); setFormError(null); }}
                options={ltypeOptions}
                placeholder={loading ? 'Loading…' : 'Choose a kind…'}
                disabled={loading}
                error={showError(errors.ltype, duplicate
                    ? `This connection already exists: “${source.name}” → “${target.name}” [${values.ltype}].`
                    : null)}
                warning={reverseExists
                    ? `"${target.name}" → "${source.name}" [${values.ltype}] already exists — the same connection the other way round. Check you have the direction you meant.`
                    : null}
            />

            <Note tone="info">
                <ul className="pdm-collab-ltypes">
                    {(metadata.ltypes || []).map((ltype) => (
                        <li key={ltype.code}>
                            <span className="pdm-collab-ltype-code">{ltype.code}</span>
                            <span
                                className={`pdm-collab-ltype-line is-${ltype.style}`}
                                aria-hidden="true"
                            />
                            <span>
                                <strong>{ltype.label}.</strong>{' '}
                                {LTYPE_MEANING[ltype.code] || ''}
                            </span>
                        </li>
                    ))}
                </ul>
            </Note>

            {/*
              * The map chooser and the sentence explaining what it contains. The
              * three states are deliberately distinct: nothing chosen yet, no map
              * in common, and a real choice.
              */}
            {!bothChosen && (
                <Note tone="info">
                    <p>
                        Choose both blocks and this form will offer the cartographies they
                        have in common. A connection can only exist in a map that holds both
                        of its endpoints.
                    </p>
                </Note>
            )}

            {noSharedMap && (
                <Note tone="warn">
                    <p>
                        <strong>These two blocks share no cartography.</strong>{' '}
                        “{source.name}” is in {describeMaps(source.maps, mapLabels)}, and
                        “{target.name}” is in {describeMaps(target.maps, mapLabels)}.
                    </p>
                    <p>
                        A connection has to live in a map that contains both of its ends, so
                        there is nothing this one could be proposed in. Either one of these
                        blocks belongs in a map it is not currently in — which is a change to
                        the block, not a new connection — or this connection is not the one
                        you meant.
                    </p>
                </Note>
            )}

            {bothChosen && !sameBlock && shared.length > 0 && (
                <CheckboxGroup
                    legend="Cartographies"
                    values={values.maps}
                    onToggle={toggleMap}
                    options={mapOptions}
                    error={errors.maps}
                    hint={
                        shared.length === 1
                            ? `Only ${describeMaps(shared, mapLabels)} is offered: it is the one cartography “${source.name}” and “${target.name}” have in common.`
                            : `Only the cartographies both blocks belong to are offered — ${describeMaps(shared, mapLabels)}. A connection in a map its endpoints are not in would silently disappear under that map's filter.`
                    }
                />
            )}
        </ProposalForm>
    );
};

/** Maps both blocks belong to. Empty until both are chosen. */
function intersectionOf(source, target) {
    if (!source || !target) return [];
    return source.maps.filter((code) => target.maps.includes(code));
}

/** "Mechatronics", or "Mechatronics and Smart Products", or a comma list. */
function describeMaps(codes, mapLabels) {
    const names = codes.map((code) => mapLabels.get(code) || code);
    if (names.length === 0) return 'no cartography';
    if (names.length === 1) return names[0];
    return `${names.slice(0, -1).join(', ')} and ${names[names.length - 1]}`;
}

export default ConnectionForm;
