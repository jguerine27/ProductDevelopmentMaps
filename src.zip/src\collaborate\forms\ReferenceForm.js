import React, { useMemo, useState } from 'react';
import apiClient from '../../api/client';
import { useCollaborateLists, referenceKey } from '../CollaborateData';
import { mapApiError } from '../apiErrors';
import ProposalForm from '../ProposalForm';
import { TextField, SelectField, Note, DerivedField, showError } from '../fields';

/**
 * Propose a reference — a published source.
 *
 * POST /api/proposals/references
 *   { author, authors_full, year, title, type,
 *     journal?, conference?, volume?, issue?, pages?, institution?,
 *     publisher?, editors?, book_title?, doi? }
 *
 * ── TYPE DRIVES THE FORM ─────────────────────────────────────────────────────
 * A thesis has an institution and no volume; a chapter has editors and a book
 * title; a standard has neither a journal nor a publisher. Rendering all
 * fourteen optional fields at once and letting the contributor work out which
 * eight to ignore produces references with a conference name in the journal box.
 * So the type is chosen first and only the fields that apply are rendered.
 *
 * ── REFERENCE_TYPES IS NOT SERVED BY THE API ─────────────────────────────────
 * /api/metadata carries levels, maps, approaches and ltypes, but not the
 * reference types — services/validation.js keeps REFERENCE_TYPES to itself. It
 * is therefore the one option list here that is written out rather than fetched.
 * The mapping from a type to the fields it needs is frontend knowledge anyway,
 * so the two belong together; if metadata ever serves the list, take the codes
 * from it and keep the field map here.
 */

/**
 * type -> the fields it adds, in the order they should appear.
 * The keys match the API's body exactly, so building the request is a filter
 * rather than a translation.
 */
const TYPES = [
    { value: 'journal', label: 'Journal article', fields: ['journal', 'volume', 'issue', 'pages'] },
    { value: 'conference', label: 'Conference paper', fields: ['conference', 'pages'] },
    { value: 'thesis', label: 'Thesis', fields: ['institution'] },
    { value: 'book', label: 'Book', fields: ['publisher'] },
    { value: 'chapter', label: 'Book chapter', fields: ['book_title', 'editors', 'publisher', 'pages'] },
    { value: 'report', label: 'Report', fields: ['institution', 'publisher'] },
    { value: 'standard', label: 'Standard', fields: ['institution'] },
];

const FIELD_SPEC = {
    journal: { label: 'Journal', placeholder: 'Research in Engineering Design', max: 4000 },
    conference: { label: 'Conference', placeholder: 'International Design Conference', max: 4000 },
    volume: { label: 'Volume', placeholder: '33', max: 32 },
    issue: { label: 'Issue', placeholder: '3', max: 32 },
    pages: { label: 'Pages', placeholder: '307–349', max: 32 },
    institution: { label: 'Institution', placeholder: 'École de technologie supérieure', max: 4000 },
    publisher: { label: 'Publisher', placeholder: 'Springer', max: 4000 },
    editors: { label: 'Editors', placeholder: 'Smith J, Jones A', max: 4000 },
    book_title: { label: 'Book title', placeholder: 'Handbook of Systems Engineering', max: 4000 },
};

const ALL_OPTIONAL_FIELDS = Object.keys(FIELD_SPEC);

const EMPTY = Object.freeze({
    type: '',
    author: '',
    authors_full: '',
    year: '',
    title: '',
    doi: '',
    ...Object.fromEntries(ALL_OPTIONAL_FIELDS.map((field) => [field, ''])),
});

const YEAR_PATTERN = /^\d{4}[A-Za-z]?$/;

/**
 * DOI is stored BARE. A pasted https://doi.org/… link is trimmed back rather
 * than rejected, because copying the URL out of a browser bar is what everyone
 * actually does. The same regex the API applies (services/validation.js), run
 * here so the contributor SEES the stripped value rather than discovering the
 * server changed what they typed.
 */
const stripDoiPrefix = (value) => value.replace(/^https?:\/\/(dx\.)?doi\.org\//i, '');

const ERROR_PATTERNS = [
    { test: /^A reference .* already exists/, field: 'author' },
];

const ReferenceForm = () => {
    const { references, referencesLoading, referencesError } = useCollaborateLists({ references: true });

    const [values, setValues] = useState(EMPTY);
    const [errors, setErrors] = useState({});
    const [formError, setFormError] = useState(null);
    const [submitting, setSubmitting] = useState(false);
    const [success, setSuccess] = useState(null);

    const set = (field, value) => {
        setValues((prev) => ({ ...prev, [field]: value }));
        setErrors((prev) => (prev[field] ? { ...prev, [field]: undefined } : prev));
        setFormError(null);
    };

    /**
     * Changing the type CLEARS the fields the old type had and the new one does
     * not. Leaving them populated but unrendered would silently submit a journal
     * name on a thesis — invisible on screen and permanent in the database.
     */
    const setType = (type) => {
        const keep = new Set(TYPES.find((entry) => entry.value === type)?.fields || []);
        setValues((prev) => {
            const next = { ...prev, type };
            for (const field of ALL_OPTIONAL_FIELDS) if (!keep.has(field)) next[field] = '';
            return next;
        });
        setErrors((prev) => ({ ...prev, type: undefined }));
        setFormError(null);
    };

    const activeFields = useMemo(
        () => TYPES.find((entry) => entry.value === values.type)?.fields || [],
        [values.type]
    );

    const trimmed = (field) => values[field].trim();

    /** (author, year) is the identity the API keys on, and it is exact. */
    const existingKeys = useMemo(() => new Set(references.map(referenceKey)), [references]);
    const duplicate = trimmed('author') && trimmed('year')
        && existingKeys.has(referenceKey({ author: trimmed('author'), year: trimmed('year') }));

    const validate = () => {
        const next = {};
        if (!values.type) next.type = 'Choose what kind of source this is — it decides which fields apply.';
        if (!trimmed('author')) next.author = 'Give the short label, as printed on the map.';
        else if (duplicate) next.author = `"${trimmed('author')} ${trimmed('year')}" is already in the bibliography.`;
        // Required here although the API accepts it as optional — see the note
        // beside the field. A reference with no full author list cannot be
        // rendered into a bibliography, which is the only reason it exists.
        if (!trimmed('authors_full')) next.authors_full = 'Give the complete author list for the bibliography.';
        if (!trimmed('year')) next.year = 'Give the year of publication.';
        else if (!YEAR_PATTERN.test(trimmed('year'))) {
            next.year = 'Four digits, with an optional letter to disambiguate — "2014", or "1996a" and "1996b".';
        }
        if (!trimmed('title')) next.title = 'Give the title of the work.';
        return next;
    };

    const canSubmit = Object.keys(validate()).length === 0 && !referencesLoading;

    const submit = async () => {
        const found = validate();
        setErrors(found);
        if (Object.keys(found).length > 0) return;

        const body = {
            author: trimmed('author'),
            authors_full: trimmed('authors_full'),
            year: trimmed('year'),
            title: trimmed('title'),
            type: values.type,
            doi: stripDoiPrefix(trimmed('doi')),
        };
        // Only the fields this type actually uses. The rest are not sent at all
        // rather than sent empty, so the request says what it means.
        for (const field of activeFields) {
            if (trimmed(field)) body[field] = trimmed(field);
        }

        setSubmitting(true);
        setFormError(null);
        try {
            const response = await apiClient.post('/api/proposals/references', body);
            const proposal = response.data?.proposal || {};
            setSuccess({
                label: `Reference — ${proposal.item || `${body.author} ${body.year}`}`,
                description: `${titleCase(values.type)}: “${body.title}”.`,
            });
        } catch (err) {
            const { field, message } = mapApiError(err, { patterns: ERROR_PATTERNS });
            if (field) setErrors((prev) => ({ ...prev, [field]: message }));
            else setFormError(message);
        } finally {
            setSubmitting(false);
        }
    };

    const reset = () => {
        setValues(EMPTY);
        setErrors({});
        setFormError(null);
        setSuccess(null);
    };

    const preview = renderCitation(values, stripDoiPrefix(trimmed('doi')));

    return (
        <ProposalForm
            title="Propose a reference"
            lede="A published source: a paper, a book, a thesis, a report or a standard. Choose the kind first — it decides which details the form asks for."
            onSubmit={submit}
            canSubmit={canSubmit}
            submitting={submitting}
            formError={formError || referencesError}
            success={success}
            onSubmitAnother={reset}
        >
            <SelectField
                label="Kind of source"
                required
                wide
                value={values.type}
                onChange={setType}
                options={TYPES}
                placeholder="Choose a kind…"
                error={errors.type}
                hint="Changing this clears any detail that does not apply to the new kind."
            />

            <TextField
                label="Short label"
                required
                value={values.author}
                onChange={(value) => set('author', value)}
                placeholder="Mhenni et al."
                maxLength={300}
                error={showError(errors.author, duplicate
                    ? `"${trimmed('author')} ${trimmed('year')}" is already in the bibliography.`
                    : null)}
                hint="What appears on the map and in the citation key — one or two surnames, then “et al.”. This is half the reference's identity, with the year."
            />

            <TextField
                label="Year"
                required
                value={values.year}
                onChange={(value) => set('year', value)}
                placeholder="2014"
                maxLength={5}
                error={errors.year}
                hint="A letter suffix disambiguates two papers by the same author in the same year — 1996a, 1996b."
            />

            <TextField
                label="Full author list"
                required
                wide
                value={values.authors_full}
                onChange={(value) => set('authors_full', value)}
                placeholder="Mhenni F, Choley JY, Penas O, et al"
                maxLength={4000}
                error={errors.authors_full}
                hint="Everyone, for the bibliography. This is a different field from the short label above — do not repeat “Mhenni et al.” here."
            />

            <TextField
                label="Title"
                required
                wide
                value={values.title}
                onChange={(value) => set('title', value)}
                placeholder="A SysML-based methodology for mechatronic systems architectural design"
                maxLength={4000}
                error={errors.title}
            />

            {activeFields.map((field) => (
                <TextField
                    key={field}
                    label={FIELD_SPEC[field].label}
                    value={values[field]}
                    onChange={(value) => set(field, value)}
                    placeholder={FIELD_SPEC[field].placeholder}
                    maxLength={FIELD_SPEC[field].max}
                    error={errors[field]}
                />
            ))}

            <TextField
                label="DOI"
                wide
                value={values.doi}
                onChange={(value) => set('doi', value)}
                placeholder="10.1016/j.aei.2014.03.006"
                maxLength={300}
                error={errors.doi}
                hint="Stored bare, without the https://doi.org/ prefix. Paste the whole link if that is what you have — the prefix is stripped for you."
                warning={values.doi !== stripDoiPrefix(values.doi)
                    ? `Stored as ${stripDoiPrefix(trimmed('doi'))}`
                    : null}
            />

            {/*
              * The live preview. Reading the rendered citation back is the
              * fastest way to notice a conference name in the journal box or a
              * page range in the volume — far faster than re-reading the form.
              */}
            <DerivedField
                label="Preview"
                wide
                empty="Fill in the fields above to see how this will be cited."
                hint="How this reference will read in the bibliography. Check it against the source."
            >
                {preview && <span>{preview}</span>}
            </DerivedField>

            <Note tone="info">
                <p>
                    <strong>This is a source, not evidence for a connection.</strong> Adding a
                    reference here puts the paper in the bibliography. Saying which connection
                    it supports is a separate act — use “Support a connection” once this has
                    been approved.
                </p>
            </Note>
        </ProposalForm>
    );
};

const titleCase = (value) => value.charAt(0).toUpperCase() + value.slice(1);

/**
 * The citation as it will read. Deliberately forgiving: it renders whatever is
 * filled in so far rather than waiting for the form to be complete, because its
 * job is to catch a wrong box early.
 */
function renderCitation(values, doi) {
    const get = (field) => values[field].trim();
    const authors = get('authors_full') || get('author');
    const year = get('year');
    const title = get('title');
    if (!authors && !year && !title) return '';

    const parts = [];
    parts.push(`${authors || '[authors]'} (${year || '[year]'}).`);
    if (title) parts.push(`${title}.`);

    switch (values.type) {
        case 'journal': {
            const journal = get('journal');
            const volume = get('volume');
            const issue = get('issue');
            const pages = get('pages');
            if (journal) parts.push(issue || volume ? `${journal},` : `${journal}.`);
            if (volume) parts.push(issue ? `${volume}(${issue}),` : `${volume},`);
            else if (issue) parts.push(`(${issue}),`);
            if (pages) parts.push(`${pages}.`);
            break;
        }
        case 'conference': {
            const conference = get('conference');
            const pages = get('pages');
            if (conference) parts.push(pages ? `In ${conference},` : `In ${conference}.`);
            if (pages) parts.push(`pp. ${pages}.`);
            break;
        }
        case 'thesis':
            if (get('institution')) parts.push(`${get('institution')}.`);
            break;
        case 'book':
            if (get('publisher')) parts.push(`${get('publisher')}.`);
            break;
        case 'chapter': {
            const bookTitle = get('book_title');
            const editors = get('editors');
            const pages = get('pages');
            const publisher = get('publisher');
            if (editors || bookTitle) {
                const inner = [editors ? `${editors} (Eds.),` : null, bookTitle || null]
                    .filter(Boolean).join(' ');
                parts.push(pages ? `In ${inner} (pp. ${pages}).` : `In ${inner}.`);
            }
            if (publisher) parts.push(`${publisher}.`);
            break;
        }
        case 'report': {
            const institution = get('institution');
            const publisher = get('publisher');
            if (institution) parts.push(`${institution}.`);
            if (publisher) parts.push(`${publisher}.`);
            break;
        }
        case 'standard':
            if (get('institution')) parts.push(`${get('institution')}.`);
            break;
        default:
            break;
    }

    // Shown as the full URL even though it is stored bare — that is how the
    // source papers print it, and how a reader would follow it.
    if (doi) parts.push(`https://doi.org/${doi}`);
    return parts.join(' ');
}

export default ReferenceForm;
