'use strict';

const express = require('express');
const { asyncHandler, notFound, AppError } = require('../../middleware/errorHandler');
const proposals = require('../../services/proposals');
const { invalid, requireString, optionalString, MAX_TEXT } = require('../../services/validation');
const { resetMapRegistry } = require('../../services/mapRegistry');

const router = express.Router();

/**
 * §4 — review. requireReviewer is applied where this router is mounted, in
 * routes/proposals/index.js, so every handler below inherits it.
 */

/**
 * A reviewer must not review their own submission.
 *
 * ── WHY THIS IS NOT OPTIONAL ─────────────────────────────────────────────────
 * Reviewer status is not gated: anyone who signs in with ORCID gets it, and
 * ORCID registration is free, self-service and needs no institutional
 * affiliation. Without this rule one person can propose a change and approve it
 * seconds later, and the review step becomes decorative. With it, every approved
 * contribution has been seen by at least two people.
 *
 * The comparison is against req.user.id, which comes from the session cookie.
 * Nothing in the request body is consulted, so it cannot be spoofed.
 *
 * ── A SINGLE-REVIEWER DEADLOCK IS POSSIBLE, AND IS NOT A BUG ─────────────────
 * If the only reviewer on an instance proposes something, nobody can approve it.
 * There is deliberately no override — an escape hatch here would be usable in
 * exactly the situation the rule exists to prevent. The 403 says so plainly, so
 * the situation reads as a policy decision rather than a defect. A second ORCID
 * sign-in resolves it.
 *
 * ── IT CONSTRAINS THE ROUTE, NOT THE PERSON ──────────────────────────────────
 * A reviewer can POST /api/blocks directly at status 'approved' without going
 * near a proposal, so this does not stop reviewers from acting — reviewers are
 * trusted to edit the map. What it stops is the REVIEW RECORD being
 * self-certified. If that trade should be tightened later, the change is to
 * remove direct creation in routes/manage, not to weaken this rule.
 */
function assertNotOwnProposal(req, proposal) {
    if (proposal.created_by === req.user.id) {
        throw new AppError(403, 'CANNOT_REVIEW_OWN_PROPOSAL',
            'You cannot review your own proposal. Another reviewer must decide on it. ' +
            'If you are currently the only reviewer, a second ORCID sign-in is needed ' +
            'before this can be approved — this restriction has no override by design.');
    }
}

/** Resolve :type and :id, or 404. */
async function loadProposal(req) {
    let type;
    try {
        type = proposals.resolveType(req.params.type);
    } catch (err) {
        throw notFound('UNKNOWN_PROPOSAL_TYPE',
            `Unknown proposal type "${req.params.type}". Valid: ${err.knownTypes.join(', ')}.`);
    }
    const proposal = await proposals.findProposal(type.slug, req.params.id);
    if (!proposal) {
        throw notFound('PROPOSAL_NOT_FOUND', `No ${type.slug} proposal with that id.`);
    }
    return { type, proposal };
}

// ── The queue ────────────────────────────────────────────────────────────────
router.get('/', asyncHandler(async (req, res) => {
    const { status, type } = req.query;

    if (status !== undefined && !proposals.STATUSES.includes(status)) {
        throw invalid(`"status" must be one of: ${proposals.STATUSES.join(', ')}.`);
    }
    if (type !== undefined && !proposals.PROPOSAL_TYPE_SLUGS.includes(type)) {
        throw invalid(`"type" must be one of: ${proposals.PROPOSAL_TYPE_SLUGS.join(', ')}.`);
    }

    const list = await proposals.listProposals({
        status: status || null,
        slug: type || null,
    });
    res.json({
        proposals: list,
        meta: { filters_applied: { status: status || null, type: type || null },
                counts: { proposals: list.length } },
    });
}));

// ── Approve ──────────────────────────────────────────────────────────────────
router.post('/:type/:id/approve', asyncHandler(async (req, res) => {
    const { type, proposal } = await loadProposal(req);
    assertNotOwnProposal(req, proposal);

    const note = optionalString(req.body || {}, 'note', { max: MAX_TEXT });
    const updated = await proposals.approveProposal(type.slug, req.params.id, req.user.id, note);

    // Approving a Map must invalidate the registry cache, or the new
    // cartography stays invisible — and unusable as a filter value — until the
    // process happens to restart. The cache reloads on the next request that
    // needs it.
    if (type.slug === 'maps') resetMapRegistry();

    res.json({ proposal: updated });
}));

// ── Reject ───────────────────────────────────────────────────────────────────
router.post('/:type/:id/reject', asyncHandler(async (req, res) => {
    const { type, proposal } = await loadProposal(req);
    assertNotOwnProposal(req, proposal);

    // Required, not optional. A submitter who receives a silent rejection learns
    // nothing and proposes the same thing again.
    const reason = requireString(req.body || {}, 'reason', { max: MAX_TEXT });

    const updated = await proposals.rejectProposal(type.slug, req.params.id, req.user.id, reason);
    res.json({ proposal: updated });
}));

// ── Request changes ──────────────────────────────────────────────────────────
router.post('/:type/:id/request-changes', asyncHandler(async (req, res) => {
    const { type, proposal } = await loadProposal(req);
    assertNotOwnProposal(req, proposal);

    const reason = requireString(req.body || {}, 'reason', { max: MAX_TEXT });
    const updated = await proposals.requestChanges(type.slug, req.params.id, req.user.id, reason);
    res.json({ proposal: updated });
}));

module.exports = router;
