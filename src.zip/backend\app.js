'use strict';

const express = require('express');
const cors = require('cors');
const config = require('./config');
const { notFoundHandler, errorHandler } = require('./middleware/errorHandler');
const { attachUser } = require('./middleware/auth');

/**
 * Builds the Express app without opening a port or a driver connection, so the
 * verification script can mount it on an ephemeral port. index.js is still the
 * process entrypoint.
 */
function createApp() {
    const app = express();

    // The old backend used a bare `cors()`, which allows every origin. The
    // allow-list comes from CORS_ORIGIN and defaults to the CRA dev server.
    //
    // credentials:true is required now that the session is an httpOnly cookie —
    // without it the browser will not send the cookie cross-origin. It also
    // makes an explicit origin mandatory: the CORS spec forbids pairing
    // `Access-Control-Allow-Credentials: true` with `*`, and browsers reject it.
    // config.corsOrigins is always a concrete list, never a wildcard.
    app.use(cors({
        origin: config.corsOrigins,
        methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE', 'OPTIONS'],
        credentials: true,
    }));
    app.use(express.json({ limit: '1mb' }));

    // Ahead of every router, so a public route can tell who is asking without
    // requiring anyone to be signed in. Never rejects.
    app.use(attachUser);

    // ── Public reads. Unchanged, and deliberately unguarded — the map is public.
    app.use('/api/health', require('./routes/health'));
    app.use('/api/graph', require('./routes/graph'));
    app.use('/api/blocks', require('./routes/blocks'));
    app.use('/api/challenges', require('./routes/challenges'));
    // GET only. POST/PATCH/DELETE /api/references belong to the manage router
    // below; Express matches on method and path together, so the two coexist on
    // the same path exactly as /api/blocks already does.
    app.use('/api/references', require('./routes/references'));
    app.use('/api/metadata', require('./routes/metadata'));

    // ── Authentication and the caller's own record.
    app.use('/api/auth', require('./routes/auth'));

    // ── Writes. Each of these mounts its guard with router.use() at the top of
    // its own index, so every route inside inherits it and none can be added
    // unguarded by omission.
    app.use('/api/admin', require('./routes/admin'));
    app.use('/api/proposals', require('./routes/proposals'));
    app.use('/api', require('./routes/manage'));

    app.use(notFoundHandler);
    app.use(errorHandler);

    return app;
}

module.exports = { createApp };
