import React from 'react';
import { fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import apiClient from '../api/client';
import { CollaborateDataProvider } from './CollaborateData';
import CollaborateHub from './CollaborateHub';
import BlockForm from './forms/BlockForm';
import ConnectionForm from './forms/ConnectionForm';
import ReferenceForm from './forms/ReferenceForm';
import ChallengeForm from './forms/ChallengeForm';
import LinkReferenceForm from './forms/LinkReferenceForm';
import ChallengeBlockForm from './forms/ChallengeBlockForm';
import CartographyForm from './forms/CartographyForm';
import MySubmissions from './MySubmissions';
import SearchableSelect from './SearchableSelect';

jest.mock('../api/client', () => ({
    __esModule: true,
    default: { get: jest.fn(), post: jest.fn(), delete: jest.fn() },
}));

const METADATA = {
    levels: ['Approach', 'Process', 'Method', 'Tool'],
    maps: [
        { code: 'M', label: 'Mechatronics' },
        { code: 'C', label: 'Cyber-Physical Systems' },
        { code: 'S', label: 'Smart Products' },
    ],
    approaches: [
        { name: 'Systems Engineering', color: '#00acef', block_count: 19 },
        { name: 'agnostic from approaches', color: '#001e5f', block_count: 133 },
    ],
    ltypes: [
        { code: 'ec', label: 'Expressly cited', style: 'solid' },
        { code: 'oc', label: 'Created for comprehension', style: 'dashed' },
        { code: 'h', label: 'Hybridization / derivative', style: 'dash-dot' },
    ],
};

/**
 * Real block names and real map memberships, taken from the live database —
 * "Virtual commissioning" and "Scrum CPS" genuinely share no cartography, and
 * "System modelling techniques" genuinely overlaps the first in M alone. Using
 * the real values means these tests fail if the data ever stops backing them.
 */
const GRAPH = {
    blocks: [
        { name: 'APTE', level: 'Method', maps: ['M'], color: '#001e5f', related_approach: 'agnostic from approaches' },
        { name: 'Virtual commissioning', level: 'Method', maps: ['M'], color: '#001e5f', related_approach: 'agnostic from approaches' },
        { name: 'Scrum CPS', level: 'Process', maps: ['C'], color: '#c10001', related_approach: 'Agile' },
        { name: 'System modelling techniques', level: 'Method', maps: ['M', 'C', 'S'], color: '#00acef', related_approach: 'Systems Engineering' },
    ],
    edges: [{
        source: 'APTE', target: 'Horned beast', ltype: 'ec',
        references: [{ author: 'Mhenni et al.', year: '2014' }],
        links: [{ source: 'APTE', target: 'Horned beast', ltype: 'ec', maps: ['M'], visible_reference_count: 1 }],
    }],
};

const REFERENCES = [
    { author: 'Mhenni et al.', year: '2014', title: '', type: '', doi: '', link_count: 3 },
    { author: 'Isermann', year: '1996a', title: '', type: '', doi: '', link_count: 1 },
    { author: 'Isermann', year: '1996b', title: '', type: '', doi: '', link_count: 2 },
];

const CHALLENGES = [
    {
        name: 'Physical prototype dependency',
        description: 'The development structure is unable to reduce the number of physical prototypes built during development',
        block_count: 6,
    },
    {
        name: 'Knowledge reuse',
        description: 'The product lacks reusability of components and knowledge from past projects.',
        block_count: 3,
    },
];

/** Overridden per test for the pages that fetch their own data. */
let mineResponse = { proposals: [] };
let challengeDetail = { blocks: [] };

beforeEach(() => {
    mineResponse = { proposals: [] };
    challengeDetail = { blocks: [] };
    apiClient.get.mockImplementation((url) => {
        if (url === '/api/metadata') return Promise.resolve({ data: METADATA });
        if (url === '/api/challenges') return Promise.resolve({ data: { challenges: CHALLENGES } });
        if (url === '/api/graph') return Promise.resolve({ data: GRAPH });
        if (url === '/api/references') return Promise.resolve({ data: { references: REFERENCES } });
        if (url === '/api/proposals/mine') return Promise.resolve({ data: mineResponse });
        if (url.startsWith('/api/challenges/')) return Promise.resolve({ data: challengeDetail });
        return Promise.reject(new Error(`unexpected ${url}`));
    });
    apiClient.post.mockReset();
    apiClient.delete.mockReset();
});

/**
 * Choose an option in a picker by typing enough of its name, then Enter.
 *
 * Async because the block list arrives from GET /api/graph: awaiting the
 * filtered option is what proves the list landed, and it doubles as the wait
 * every one of these tests would otherwise need before asserting.
 */
const pick = async (label, text) => {
    const input = screen.getByRole('combobox', { name: new RegExp(label) });
    fireEvent.focus(input);
    fireEvent.change(input, { target: { value: text } });
    await screen.findByRole('option', { name: new RegExp(text, 'i') });
    fireEvent.keyDown(input, { key: 'ArrowDown' });
    fireEvent.keyDown(input, { key: 'Enter' });
};

// The two relationship forms label their button for what it does, since they
// are not submitting anything for review.
const submitButton = (name = 'Submit') => screen.getByRole('button', { name });

/** Submit is also gated on the lists having loaded, so this waits for both. */
const awaitEnabled = (name) => waitFor(() => expect(submitButton(name)).toBeEnabled());

const show = (ui) => render(
    <MemoryRouter><CollaborateDataProvider>{ui}</CollaborateDataProvider></MemoryRouter>
);

it('the hub lists the five primary types, the pair, and cartography quietly', () => {
    show(<CollaborateHub />);
    for (const label of ['Block', 'Connection', 'Reference', 'Challenge']) {
        expect(screen.getByRole('link', { name: new RegExp(label) })).toBeInTheDocument();
    }
    expect(screen.getByRole('link', { name: /Support a connection/ })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /Address a challenge/ })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /propose an entire new\s+cartography/ })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'My submissions' })).toBeInTheDocument();
});

describe('the block form', () => {
    it('derives the colour from the approach and offers no way to set it', async () => {
        show(<BlockForm />);
        await screen.findByRole('option', { name: /Systems Engineering/ });

        fireEvent.change(screen.getByLabelText(/Approach family/), { target: { value: 'Systems Engineering' } });

        const swatch = document.querySelector('.pdm-collab-swatch');
        expect(swatch).toHaveStyle({ background: '#00acef' });
        expect(screen.getByText('#00acef')).toBeInTheDocument();

        // The colour is SHOWN, under a label, but there is no control that takes
        // one — that is the whole point. A labelled group is not a control.
        const colour = screen.getByRole('group', { name: /^Colour/ });
        expect(colour.querySelector('input, select, textarea')).toBeNull();
        expect(document.querySelector('input[type="color"]')).toBeNull();
    });

    it('keeps submit disabled until every required field is answered', async () => {
        show(<BlockForm />);
        await screen.findByRole('option', { name: /Systems Engineering/ });
        const submit = screen.getByRole('button', { name: 'Submit' });
        expect(submit).toBeDisabled();

        fireEvent.change(screen.getByLabelText(/^Name/), { target: { value: 'Safety analysis' } });
        expect(submit).toBeDisabled();
        fireEvent.change(screen.getByLabelText(/^Level/), { target: { value: 'Method' } });
        fireEvent.change(screen.getByLabelText(/Approach family/), { target: { value: 'Systems Engineering' } });
        expect(submit).toBeDisabled();          // no map chosen yet
        fireEvent.click(screen.getByRole('checkbox', { name: /Mechatronics/ }));
        expect(submit).toBeEnabled();
    });

    it('blocks a name that already exists rather than spending a round trip on it', async () => {
        show(<BlockForm />);
        await screen.findByRole('option', { name: /Systems Engineering/ });

        fireEvent.change(screen.getByLabelText(/^Name/), { target: { value: 'APTE' } });
        fireEvent.change(screen.getByLabelText(/^Level/), { target: { value: 'Method' } });
        fireEvent.change(screen.getByLabelText(/Approach family/), { target: { value: 'Systems Engineering' } });
        fireEvent.click(screen.getByRole('checkbox', { name: /Mechatronics/ }));

        expect(screen.getByRole('button', { name: 'Submit' })).toBeDisabled();
        expect(apiClient.post).not.toHaveBeenCalled();
    });

    it('sends the derived colour and shows a pending success state', async () => {
        apiClient.post.mockResolvedValue({ data: { proposal: { id: 'x', item: 'Safety analysis', status: 'pending' } } });
        show(<BlockForm />);
        await screen.findByRole('option', { name: /Systems Engineering/ });

        fireEvent.change(screen.getByLabelText(/^Name/), { target: { value: 'Safety analysis' } });
        fireEvent.change(screen.getByLabelText(/^Level/), { target: { value: 'Method' } });
        fireEvent.change(screen.getByLabelText(/Approach family/), { target: { value: 'Systems Engineering' } });
        fireEvent.click(screen.getByRole('checkbox', { name: /Mechatronics/ }));
        fireEvent.click(screen.getByRole('button', { name: 'Submit' }));

        await waitFor(() => expect(apiClient.post).toHaveBeenCalled());
        expect(apiClient.post).toHaveBeenCalledWith('/api/proposals/blocks', {
            name: 'Safety analysis', level: 'Method', maps: ['M'],
            related_approach: 'Systems Engineering', color: '#00acef', citations: '',
        });
        expect(await screen.findByText('Submitted for review')).toBeInTheDocument();
        expect(screen.getByText(/will not appear on\s+the map until a peer reviewer approves it/)).toBeInTheDocument();
    });

    it('puts a 422 on the field it belongs to, not in a raw banner', async () => {
        apiClient.post.mockRejectedValue({
            response: { status: 422, data: { error: { code: 'VALIDATION_FAILED', message: 'A block named "Safety analysis" already exists (status: pending).' } } },
        });
        show(<BlockForm />);
        await screen.findByRole('option', { name: /Systems Engineering/ });

        fireEvent.change(screen.getByLabelText(/^Name/), { target: { value: 'Safety analysis' } });
        fireEvent.change(screen.getByLabelText(/^Level/), { target: { value: 'Method' } });
        fireEvent.change(screen.getByLabelText(/Approach family/), { target: { value: 'Systems Engineering' } });
        fireEvent.click(screen.getByRole('checkbox', { name: /Mechatronics/ }));
        fireEvent.click(screen.getByRole('button', { name: 'Submit' }));

        const name = await screen.findByLabelText(/^Name/);
        await waitFor(() => expect(name).toHaveAttribute('aria-invalid', 'true'));
        const errorId = name.getAttribute('aria-describedby').split(' ')[0];
        expect(document.getElementById(errorId)).toHaveTextContent('already exists');
        expect(screen.queryByRole('alert')).toBeNull();
    });
});

/**
 * The map-intersection rule. A link may only exist in a map holding BOTH of its
 * endpoints; a violation vanishes silently under that map's filter rather than
 * erroring, so the form must never let one be submitted.
 */
describe('the connection form', () => {
    it('offers no map and blocks submission for two blocks sharing none', async () => {
        show(<ConnectionForm />);

        await pick('From \\(source\\)', 'Virtual commissioning');
        await pick('To \\(target\\)', 'Scrum CPS');

        // The explanation names both blocks and the maps each is actually in,
        // rather than the API's two raw JSON arrays.
        expect(screen.getByText(/These two blocks share no cartography/)).toBeInTheDocument();
        expect(screen.getByText(/Mechatronics/)).toBeInTheDocument();
        expect(screen.getByText(/Cyber-Physical Systems/)).toBeInTheDocument();

        // No map chooser at all — there is nothing valid to offer.
        expect(screen.queryByRole('checkbox')).toBeNull();
        expect(submitButton()).toBeDisabled();
        expect(apiClient.post).not.toHaveBeenCalled();
    });

    it('offers only the single map an overlapping pair shares', async () => {
        show(<ConnectionForm />);

        // M,C,S  ∩  M  =  M
        await pick('From \\(source\\)', 'System modelling');
        await pick('To \\(target\\)', 'Virtual commissioning');

        const boxes = screen.getAllByRole('checkbox');
        expect(boxes).toHaveLength(1);
        expect(screen.getByRole('checkbox', { name: /Mechatronics/ })).toBeInTheDocument();
        expect(screen.queryByRole('checkbox', { name: /Smart Products/ })).toBeNull();
        expect(screen.getByText(/it is the one cartography/)).toBeInTheDocument();
    });

    it('drops a ticked map that the new endpoint does not share', async () => {
        show(<ConnectionForm />);

        // M,C,S  ∩  M  =  M, and M is ticked.
        await pick('From \\(source\\)', 'System modelling');
        await pick('To \\(target\\)', 'APTE');
        fireEvent.click(screen.getByRole('checkbox', { name: /Mechatronics/ }));
        fireEvent.change(screen.getByLabelText(/Kind of connection/), { target: { value: 'ec' } });
        await awaitEnabled();

        // Swapping the target moves the intersection to C. The ticked M is no
        // longer offered and must not survive as an invisible selection — if it
        // did, submitting would send a map the new pair does not share.
        await pick('To \\(target\\)', 'Scrum CPS');
        expect(screen.queryByRole('checkbox', { name: /Mechatronics/ })).toBeNull();
        expect(screen.getByRole('checkbox', { name: /Cyber-Physical Systems/ })).not.toBeChecked();
        expect(submitButton()).toBeDisabled();
    });

    it('spells out what each link type claims', async () => {
        show(<ConnectionForm />);

        // Every code is explained; none of them means anything on its own.
        expect(await screen.findByText(/The literature states this connection outright/)).toBeInTheDocument();
        expect(screen.getByText(/make the map readable/)).toBeInTheDocument();
        expect(screen.getByText(/derived from the other/)).toBeInTheDocument();
    });

    it('sends only the shared map', async () => {
        apiClient.post.mockResolvedValue({
            data: { proposal: { id: 'l1', item: 'System modelling techniques -> APTE [ec]', status: 'pending' } },
        });
        show(<ConnectionForm />);

        await pick('From \\(source\\)', 'System modelling');
        await pick('To \\(target\\)', 'APTE');
        fireEvent.change(screen.getByLabelText(/Kind of connection/), { target: { value: 'ec' } });
        fireEvent.click(screen.getByRole('checkbox', { name: /Mechatronics/ }));
        await awaitEnabled();
        fireEvent.click(submitButton());

        await waitFor(() => expect(apiClient.post).toHaveBeenCalled());
        expect(apiClient.post).toHaveBeenCalledWith('/api/proposals/links', {
            source: 'System modelling techniques', target: 'APTE', ltype: 'ec', maps: ['M'],
        });
    });

    it('refuses a connection from a block to itself', async () => {
        show(<ConnectionForm />);

        await pick('From \\(source\\)', 'APTE');
        await pick('To \\(target\\)', 'APTE');
        fireEvent.change(screen.getByLabelText(/Kind of connection/), { target: { value: 'ec' } });

        expect(submitButton()).toBeDisabled();
        fireEvent.click(submitButton());
        expect(apiClient.post).not.toHaveBeenCalled();
    });
});

describe('the reference form', () => {
    // Deliberately NOT "Mhenni et al. 2014" — that pair is in the mocked
    // bibliography, and the duplicate rule would block submit for the wrong
    // reason in every test below.
    const fill = () => {
        fireEvent.change(screen.getByLabelText(/Short label/), { target: { value: 'Guérineau et al.' } });
        fireEvent.change(screen.getByLabelText(/^Year/), { target: { value: '2022' } });
        fireEvent.change(screen.getByLabelText(/Full author list/), { target: { value: 'Guérineau V, Bricogne M' } });
        fireEvent.change(screen.getByLabelText(/^Title/), { target: { value: 'Considering product development' } });
    };

    it('renders only the fields the chosen type uses', async () => {
        show(<ReferenceForm />);
        await screen.findByLabelText(/Kind of source/);

        // Nothing conditional before a type is chosen.
        expect(screen.queryByLabelText(/^Journal/)).toBeNull();
        expect(screen.queryByLabelText(/^Institution/)).toBeNull();

        fireEvent.change(screen.getByLabelText(/Kind of source/), { target: { value: 'journal' } });
        for (const label of [/^Journal/, /^Volume/, /^Issue/, /^Pages/]) {
            expect(screen.getByLabelText(label)).toBeInTheDocument();
        }
        expect(screen.queryByLabelText(/^Institution/)).toBeNull();

        // A chapter shows book_title and editors; a thesis shows institution only.
        fireEvent.change(screen.getByLabelText(/Kind of source/), { target: { value: 'chapter' } });
        expect(screen.getByLabelText(/^Book title/)).toBeInTheDocument();
        expect(screen.getByLabelText(/^Editors/)).toBeInTheDocument();
        expect(screen.getByLabelText(/^Publisher/)).toBeInTheDocument();
        expect(screen.queryByLabelText(/^Journal/)).toBeNull();

        fireEvent.change(screen.getByLabelText(/Kind of source/), { target: { value: 'thesis' } });
        expect(screen.getByLabelText(/^Institution/)).toBeInTheDocument();
        for (const label of [/^Journal/, /^Volume/, /^Publisher/, /^Book title/, /^Editors/]) {
            expect(screen.queryByLabelText(label)).toBeNull();
        }
    });

    it('clears a field the new type does not use, rather than sending it unseen', async () => {
        apiClient.post.mockResolvedValue({ data: { proposal: { item: 'Mhenni et al. 2014', status: 'pending' } } });
        show(<ReferenceForm />);
        await screen.findByLabelText(/Kind of source/);

        fireEvent.change(screen.getByLabelText(/Kind of source/), { target: { value: 'journal' } });
        fireEvent.change(screen.getByLabelText(/^Journal/), { target: { value: 'Research in Engineering Design' } });
        fireEvent.change(screen.getByLabelText(/Kind of source/), { target: { value: 'thesis' } });
        fireEvent.change(screen.getByLabelText(/^Institution/), { target: { value: 'ETS' } });
        fill();
        await awaitEnabled();
        fireEvent.click(submitButton());

        await waitFor(() => expect(apiClient.post).toHaveBeenCalled());
        const [, body] = apiClient.post.mock.calls[0];
        expect(body.institution).toBe('ETS');
        expect(body).not.toHaveProperty('journal');
    });

    it('accepts a year with a disambiguating suffix', async () => {
        apiClient.post.mockResolvedValue({ data: { proposal: { item: 'Isermann 1996c', status: 'pending' } } });
        show(<ReferenceForm />);
        await screen.findByLabelText(/Kind of source/);

        fireEvent.change(screen.getByLabelText(/Kind of source/), { target: { value: 'book' } });
        fill();
        fireEvent.change(screen.getByLabelText(/Short label/), { target: { value: 'Isermann' } });
        fireEvent.change(screen.getByLabelText(/^Year/), { target: { value: '1996c' } });

        await awaitEnabled();
        fireEvent.click(submitButton());
        await waitFor(() => expect(apiClient.post).toHaveBeenCalled());
        expect(apiClient.post.mock.calls[0][1].year).toBe('1996c');
    });

    it('blocks an (author, year) that is already in the bibliography', async () => {
        show(<ReferenceForm />);
        await screen.findByLabelText(/Kind of source/);

        fireEvent.change(screen.getByLabelText(/Kind of source/), { target: { value: 'book' } });
        fill();
        fireEvent.change(screen.getByLabelText(/Short label/), { target: { value: 'Isermann' } });
        // 1996c is free, and reaching "enabled" also proves the bibliography
        // has loaded — otherwise "disabled" below would prove nothing.
        fireEvent.change(screen.getByLabelText(/^Year/), { target: { value: '1996c' } });
        await awaitEnabled();

        fireEvent.change(screen.getByLabelText(/^Year/), { target: { value: '1996a' } });
        expect(submitButton()).toBeDisabled();
        fireEvent.change(screen.getByLabelText(/^Year/), { target: { value: '1996b' } });
        expect(submitButton()).toBeDisabled();
    });

    it('strips a pasted DOI URL down to the bare identifier', async () => {
        apiClient.post.mockResolvedValue({ data: { proposal: { item: 'Mhenni et al. 2014', status: 'pending' } } });
        show(<ReferenceForm />);
        await screen.findByLabelText(/Kind of source/);

        fireEvent.change(screen.getByLabelText(/Kind of source/), { target: { value: 'journal' } });
        fill();
        fireEvent.change(screen.getByLabelText(/^DOI/), {
            target: { value: 'https://doi.org/10.1016/j.aei.2014.03.006' },
        });

        // Said out loud before submitting, not silently changed on the server.
        expect(screen.getByText('Stored as 10.1016/j.aei.2014.03.006')).toBeInTheDocument();

        await awaitEnabled();
        fireEvent.click(submitButton());
        await waitFor(() => expect(apiClient.post).toHaveBeenCalled());
        expect(apiClient.post.mock.calls[0][1].doi).toBe('10.1016/j.aei.2014.03.006');
    });

    it('previews the citation as it will read, DOI as a followable URL', async () => {
        show(<ReferenceForm />);
        await screen.findByLabelText(/Kind of source/);

        fireEvent.change(screen.getByLabelText(/Kind of source/), { target: { value: 'journal' } });
        fill();
        fireEvent.change(screen.getByLabelText(/^Journal/), { target: { value: 'Research in Engineering Design' } });
        fireEvent.change(screen.getByLabelText(/^Volume/), { target: { value: '33' } });
        fireEvent.change(screen.getByLabelText(/^Issue/), { target: { value: '3' } });
        fireEvent.change(screen.getByLabelText(/^Pages/), { target: { value: '307-349' } });
        fireEvent.change(screen.getByLabelText(/^DOI/), { target: { value: '10.1007/s00163-022-00390-3' } });

        const preview = screen.getByRole('group', { name: /^Preview/ });
        expect(preview).toHaveTextContent(
            'Guérineau V, Bricogne M (2022). Considering product development. '
            + 'Research in Engineering Design, 33(3), 307-349. '
            + 'https://doi.org/10.1007/s00163-022-00390-3'
        );
    });
});

describe('the challenge form', () => {
    it('teaches the house style with real examples from the API', async () => {
        show(<ChallengeForm />);

        // Read from GET /api/challenges, not written into the component.
        expect(await screen.findByText(/The development structure is unable to reduce/)).toBeInTheDocument();
        expect(screen.getByText(/reusability of components/)).toBeInTheDocument();
    });

    it('blocks a name that already exists', async () => {
        show(<ChallengeForm />);
        await screen.findByText(/reusability of components/);

        fireEvent.change(screen.getByLabelText(/^Name/), { target: { value: 'knowledge reuse' } });
        fireEvent.change(screen.getByLabelText(/^Description/), { target: { value: 'Something else entirely' } });
        expect(submitButton()).toBeDisabled();

        fireEvent.change(screen.getByLabelText(/^Name/), { target: { value: 'Tooling reuse' } });
        await awaitEnabled();
    });
});

/**
 * The two relationship forms. Neither creates a proposal, so neither may claim
 * to be awaiting review.
 */
describe('support a connection', () => {
    it('warns up front that it is not reviewed', async () => {
        show(<LinkReferenceForm />);
        expect(await screen.findByText(/This takes effect immediately/)).toBeInTheDocument();
        expect(screen.getByText(/cannot withdraw it afterwards/)).toBeInTheDocument();
    });

    it('offers only the chosen connection\'s own maps', async () => {
        show(<LinkReferenceForm />);

        // No map chooser until a connection is picked.
        expect(screen.queryByRole('checkbox', { name: /Mechatronics/ })).toBeNull();

        await pick('Connection', 'Horned beast');
        expect(screen.getByRole('checkbox', { name: /Mechatronics/ })).toBeInTheDocument();
        // The link is in M only, so C and S are not on offer.
        expect(screen.queryByRole('checkbox', { name: /Cyber-Physical/ })).toBeNull();
        expect(screen.queryByRole('checkbox', { name: /Smart Products/ })).toBeNull();
    });

    it('explains the asterisk and grey flags and sends them', async () => {
        apiClient.post.mockResolvedValue({
            data: { link_reference: { item: 'APTE -> Horned beast [ec] : Isermann 1996a', reference_count: 2 } },
        });
        show(<LinkReferenceForm />);

        expect(await screen.findByText(/does not state the connection\s+outright/)).toBeInTheDocument();
        expect(screen.getByText(/cited to make the\s+map understandable/)).toBeInTheDocument();

        await pick('Connection', 'Horned beast');
        await pick('Reference', 'Isermann 1996a');
        fireEvent.click(screen.getByRole('checkbox', { name: /Interpreted/ }));
        fireEvent.click(screen.getByRole('checkbox', { name: /Mechatronics/ }));

        await waitFor(() => expect(screen.getByRole('button', { name: 'Record evidence' })).toBeEnabled());
        fireEvent.click(screen.getByRole('button', { name: 'Record evidence' }));

        await waitFor(() => expect(apiClient.post).toHaveBeenCalled());
        expect(apiClient.post).toHaveBeenCalledWith('/api/proposals/link-references', {
            link: { source: 'APTE', target: 'Horned beast', ltype: 'ec' },
            reference: { author: 'Isermann', year: '1996a' },
            asterisk: true, grey: false, maps: ['M'],
        });

        // The success state must NOT say "awaiting review" — it is already live.
        expect(await screen.findByText('Recorded on the map')).toBeInTheDocument();
        expect(screen.getByText(/took effect immediately/)).toBeInTheDocument();
        expect(screen.queryByText(/awaiting review/i)).toBeNull();
        expect(screen.queryByText(/peer reviewer approves/i)).toBeNull();
        // And offers no link to a submissions list it will never appear in.
        expect(screen.queryByRole('link', { name: 'My submissions' })).toBeNull();
    });
});

describe('address a challenge', () => {
    it('warns that it is not reviewed, and shows what is already recorded', async () => {
        challengeDetail = { blocks: [{ name: 'APTE' }] };
        show(<ChallengeBlockForm />);

        expect(await screen.findByText(/This takes effect immediately/)).toBeInTheDocument();

        await pick('Challenge', 'Physical prototype');
        expect(await screen.findByText(/Already addressed by: APTE/)).toBeInTheDocument();
        // The challenge's own description, so the pairing can be judged.
        expect(screen.getByText(/unable to reduce the number of physical prototypes/)).toBeInTheDocument();
    });

    it('blocks a pairing that already exists — the API would merge it silently', async () => {
        challengeDetail = { blocks: [{ name: 'APTE' }] };
        show(<ChallengeBlockForm />);

        await pick('Challenge', 'Physical prototype');
        await screen.findByText(/Already addressed by: APTE/);
        await pick('Block', 'APTE');

        expect(submitButton('Record the pairing')).toBeDisabled();
        // And it SAYS why. A disabled button with no explanation would be
        // unfixable, because the message only ever rendered on submit.
        expect(screen.getByText(/is already recorded against/)).toBeInTheDocument();

        await pick('Block', 'Scrum CPS');
        await awaitEnabled('Record the pairing');
    });
});

describe('the cartography form', () => {
    it('uppercases the code as it is typed and says it is permanent', async () => {
        show(<CartographyForm />);
        await screen.findByLabelText(/^Code/);

        expect(screen.getByText(/The code is permanent/)).toBeInTheDocument();

        fireEvent.change(screen.getByLabelText(/^Code/), { target: { value: 'r' } });
        expect(screen.getByLabelText(/^Code/)).toHaveValue('R');
    });

    it('rejects a code that is not a short uppercase token, and one already taken', async () => {
        show(<CartographyForm />);
        await screen.findByLabelText(/^Code/);
        fireEvent.change(screen.getByLabelText(/^Name/), { target: { value: 'Robotic Systems' } });

        fireEvent.change(screen.getByLabelText(/^Code/), { target: { value: '1R' } });
        expect(submitButton()).toBeDisabled();

        // M is already Mechatronics.
        fireEvent.change(screen.getByLabelText(/^Code/), { target: { value: 'M' } });
        expect(submitButton()).toBeDisabled();
        expect(screen.getByText(/already the code for Mechatronics/)).toBeInTheDocument();

        fireEvent.change(screen.getByLabelText(/^Code/), { target: { value: 'R' } });
        await awaitEnabled();
    });

    it('omits source_reference entirely when none is chosen', async () => {
        apiClient.post.mockResolvedValue({ data: { proposal: { item: 'R (Robotic Systems)', status: 'pending' } } });
        show(<CartographyForm />);
        await screen.findByLabelText(/^Code/);

        fireEvent.change(screen.getByLabelText(/^Code/), { target: { value: 'R' } });
        fireEvent.change(screen.getByLabelText(/^Name/), { target: { value: 'Robotic Systems' } });
        await awaitEnabled();
        fireEvent.click(submitButton());

        await waitFor(() => expect(apiClient.post).toHaveBeenCalled());
        expect(apiClient.post.mock.calls[0][1]).not.toHaveProperty('source_reference');
    });
});

describe('my submissions', () => {
    const PENDING = {
        id: 'p1', type: 'blocks', item: 'Safety analysis', status: 'pending',
        created_at: '2026-08-10T10:00:00Z', rejection_reason: '', review_note: '',
        properties: { level: 'Method', maps: ['M'], related_approach: 'Systems Engineering' },
    };
    const REJECTED = {
        id: 'p2', type: 'challenges', item: 'Tooling reuse', status: 'rejected',
        created_at: '2026-08-09T10:00:00Z',
        rejection_reason: 'Duplicates "Knowledge reuse"; please extend that one instead.',
        review_note: '', properties: { description: 'The product lacks tooling reuse' },
    };
    const APPROVED = {
        id: 'p3', type: 'references', item: 'Mhenni et al. 2014', status: 'approved',
        created_at: '2026-08-08T10:00:00Z', rejection_reason: '', review_note: 'Good catch.',
        properties: { type: 'journal', title: 'A SysML-based methodology' },
    };

    it('groups by status with pending first, and shows the reviewer\'s reason', async () => {
        mineResponse = { proposals: [APPROVED, REJECTED, PENDING] };
        show(<MySubmissions />);

        const headings = (await screen.findAllByRole('heading', { level: 2 })).map((h) => h.textContent);
        expect(headings).toEqual(['Awaiting review (1)', 'Approved (1)', 'Rejected (1)']);

        // The reason is the entire point of requiring one.
        expect(screen.getByText(/Duplicates "Knowledge reuse"/)).toBeInTheDocument();
        expect(screen.getByText(/Good catch\./)).toBeInTheDocument();
    });

    it('offers withdraw on pending only, and confirms first', async () => {
        mineResponse = { proposals: [PENDING, APPROVED] };
        apiClient.delete.mockResolvedValue({ data: {} });
        show(<MySubmissions />);

        // One Withdraw button: the approved one has none.
        const withdraw = await screen.findByRole('button', { name: 'Withdraw' });
        fireEvent.click(withdraw);

        // Nothing has been sent yet — it asks first.
        expect(apiClient.delete).not.toHaveBeenCalled();
        expect(screen.getByText(/It cannot be undone/)).toBeInTheDocument();

        fireEvent.click(screen.getByRole('button', { name: 'Yes, withdraw' }));
        await waitFor(() => expect(apiClient.delete).toHaveBeenCalledWith('/api/proposals/blocks/p1'));
        expect(await screen.findByText(/Withdrawn: Safety analysis/)).toBeInTheDocument();
        expect(screen.queryByText('Safety analysis')).toBeNull();
    });

    it('says plainly that the two relationship forms never appear here', async () => {
        mineResponse = { proposals: [PENDING] };
        show(<MySubmissions />);
        expect(await screen.findByText(/never appear here/)).toBeInTheDocument();
    });

    it('lists a proposal whose status it does not recognise rather than hiding it', async () => {
        mineResponse = {
            proposals: [{ ...PENDING, id: 'p9', status: 'escalated', item: 'Odd one' }],
        };
        show(<MySubmissions />);

        expect(await screen.findByText('Odd one')).toBeInTheDocument();
        expect(screen.getByRole('heading', { level: 2, name: /Other \(1\)/ })).toBeInTheDocument();
    });
});

describe('the searchable picker', () => {
    const ITEMS = [
        { name: 'APTE', level: 'Method' },
        { name: 'Agile', level: 'Approach' },
        { name: 'V-model', level: 'Process' },
    ];
    const picker = (props = {}) => render(
        <SearchableSelect
            label="Source block"
            items={ITEMS}
            value={null}
            onChange={jest.fn()}
            getKey={(b) => b.name}
            getLabel={(b) => b.name}
            getMeta={(b) => b.level}
            required
            {...props}
        />
    );

    it('filters in memory and shows each row’s secondary context', () => {
        picker();
        const input = screen.getByRole('combobox', { name: /Source block/ });
        fireEvent.focus(input);
        expect(screen.getAllByRole('option')).toHaveLength(3);

        fireEvent.change(input, { target: { value: 'ag' } });
        const options = screen.getAllByRole('option');
        expect(options).toHaveLength(1);
        expect(within(options[0]).getByText('Approach')).toBeInTheDocument();
    });

    it('reports the open list and the active option through ARIA', () => {
        picker();
        const input = screen.getByRole('combobox', { name: /Source block/ });
        expect(input).toHaveAttribute('aria-expanded', 'false');

        fireEvent.focus(input);
        expect(input).toHaveAttribute('aria-expanded', 'true');
        expect(input).not.toHaveAttribute('aria-activedescendant');

        fireEvent.keyDown(input, { key: 'ArrowDown' });
        const active = input.getAttribute('aria-activedescendant');
        expect(document.getElementById(active)).toHaveClass('is-active');
    });

    it('chooses with Enter and closes on Escape without changing anything', () => {
        const onChange = jest.fn();
        picker({ onChange });
        const input = screen.getByRole('combobox', { name: /Source block/ });

        fireEvent.focus(input);
        fireEvent.keyDown(input, { key: 'ArrowDown' });
        fireEvent.keyDown(input, { key: 'ArrowDown' });
        fireEvent.keyDown(input, { key: 'Enter' });
        expect(onChange).toHaveBeenCalledWith(ITEMS[1]);

        onChange.mockClear();
        fireEvent.focus(input);
        fireEvent.keyDown(input, { key: 'Escape' });
        expect(input).toHaveAttribute('aria-expanded', 'false');
        expect(onChange).not.toHaveBeenCalled();
    });

    it('loads its list once — never a request per keystroke', () => {
        picker();
        const input = screen.getByRole('combobox', { name: /Source block/ });
        fireEvent.focus(input);
        for (const value of ['v', 'v-', 'v-m']) fireEvent.change(input, { target: { value } });
        expect(apiClient.get).not.toHaveBeenCalled();
    });
});
