import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import apiClient from '../api/client';
import { describeError, isCanceled } from './apiErrors';

/**
 * What a contributor has sent, and what happened to it.
 *
 * GET    /api/proposals/mine
 * DELETE /api/proposals/:type/:id     (own, pending only)
 *
 * ── PENDING FIRST ────────────────────────────────────────────────────────────
 * Pending and changes-requested are the two states a contributor can still act
 * on, so they lead. Approved and rejected are history and sit below.
 *
 * ── THE REJECTION REASON IS THE POINT ────────────────────────────────────────
 * A rejection with no reason teaches nothing and the same proposal comes back
 * next week. `rejection_reason` IS carried by GET /api/proposals/mine — verified
 * against the live API — so it is shown in full rather than summarised.
 *
 * ── TWO OF THE SEVEN FORMS NEVER APPEAR HERE ─────────────────────────────────
 * "Support a connection" and "Address a challenge" create relationships, and a
 * relationship has no status, no id and no entry in this list. Saying nothing
 * about them would leave a contributor who used those forms staring at a list
 * that does not contain their work, wondering whether it was lost.
 */

/** Display order, and what each state means to the person who sent it. */
const GROUPS = [
    {
        status: 'pending',
        title: 'Awaiting review',
        note: 'Not on the map yet. You can withdraw anything here.',
    },
    {
        status: 'changes_requested',
        title: 'Changes requested',
        note: 'A reviewer has asked for something to be different before this can be approved.',
    },
    {
        status: 'approved',
        title: 'Approved',
        note: 'On the map. Changing or removing these is a reviewer’s job now.',
    },
    {
        status: 'rejected',
        title: 'Rejected',
        note: 'Not added, with the reviewer’s reason below.',
    },
];

/** Proposal type slug -> how to name it in a sentence. */
const TYPE_LABEL = {
    blocks: 'Block',
    links: 'Connection',
    references: 'Reference',
    challenges: 'Challenge',
    maps: 'Cartography',
};

/** ISO-ish timestamp -> a date a person reads. Falls back to the raw string. */
function formatWhen(value) {
    if (!value) return '';
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) return String(value);
    return parsed.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

/**
 * A one-line description of what was actually submitted, from the properties
 * the API returns alongside each proposal. `item` alone is often just a name.
 */
function describeProposal(proposal) {
    const properties = proposal.properties || {};
    switch (proposal.type) {
        case 'blocks': {
            const parts = [properties.level, (properties.maps || []).join(', ')].filter(Boolean);
            const approach = properties.related_approach;
            if (approach) parts.push(`filed under “${approach}”`);
            return parts.join(' · ');
        }
        case 'links':
            return [properties.ltype ? `[${properties.ltype}]` : null, (properties.maps || []).join(', ')]
                .filter(Boolean).join(' · ');
        case 'references':
            return [properties.type, properties.title].filter(Boolean).join(' · ');
        case 'challenges':
            return properties.description || '';
        case 'maps':
            return properties.description || properties.label || '';
        default:
            return '';
    }
}

const MySubmissions = () => {
    const [proposals, setProposals] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    // The proposal awaiting a confirmed withdrawal, and the one in flight.
    const [confirming, setConfirming] = useState(null);
    const [withdrawing, setWithdrawing] = useState(null);
    const [notice, setNotice] = useState(null);

    const alive = useRef(true);
    useEffect(() => {
        alive.current = true;
        return () => { alive.current = false; };
    }, []);

    const load = useCallback((signal) => {
        setLoading(true);
        return apiClient.get('/api/proposals/mine', { signal })
            .then((response) => {
                if (!alive.current) return;
                setProposals(response.data?.proposals || []);
                setError(null);
            })
            .catch((err) => {
                if (!alive.current || isCanceled(err)) return;
                setError(describeError(err));
            })
            .finally(() => {
                if (alive.current) setLoading(false);
            });
    }, []);

    useEffect(() => {
        const controller = new AbortController();
        load(controller.signal);
        return () => controller.abort();
    }, [load]);

    const withdraw = async (proposal) => {
        setWithdrawing(proposal.id);
        setNotice(null);
        try {
            await apiClient.delete(`/api/proposals/${proposal.type}/${encodeURIComponent(proposal.id)}`);
            if (!alive.current) return;
            // Removed locally rather than re-fetched: the list is the only thing
            // that changed, and a refetch would flash the whole page.
            setProposals((prev) => prev.filter((entry) => entry.id !== proposal.id));
            setNotice(`Withdrawn: ${proposal.item}`);
            setConfirming(null);
        } catch (err) {
            if (!alive.current) return;
            // The API answers one message for "not found", "not yours" and "no
            // longer pending" alike, so a reviewer acting first lands here.
            setError(describeError(err));
            setConfirming(null);
        } finally {
            if (alive.current) setWithdrawing(null);
        }
    };

    const grouped = useMemo(() => GROUPS.map((group) => ({
        ...group,
        items: proposals.filter((proposal) => proposal.status === group.status),
    })), [proposals]);

    // Anything whose status is not one of the four above still has to appear:
    // silently dropping a proposal because its state is unrecognised is the one
    // failure this page must not have.
    const unknown = useMemo(
        () => proposals.filter((proposal) => !GROUPS.some((group) => group.status === proposal.status)),
        [proposals]
    );

    return (
        <>
            <div className="pdm-collab-head">
                <p className="pdm-collab-eyebrow">Collaborate</p>
                <h1>My submissions</h1>
                <p className="pdm-collab-lede">
                    Everything you have proposed, and where it got to.
                </p>
            </div>

            {error && (
                <div className="pdm-collab-panel pdm-collab-panel-error" role="alert">
                    {error}
                </div>
            )}
            {notice && (
                <div className="pdm-collab-panel pdm-collab-panel-success" role="status">
                    {notice}
                </div>
            )}

            {loading && <p className="pdm-collab-status">Loading your submissions…</p>}

            {!loading && !error && proposals.length === 0 && (
                <div className="pdm-collab-form-card">
                    <h1>Nothing yet</h1>
                    <p className="pdm-collab-form-lede">
                        You have not proposed anything. Anything you send from the Collaborate
                        forms will appear here with its review status.
                    </p>
                    <Link className="pdm-collab-ghost" to="/collaborate">Make a contribution</Link>
                </div>
            )}

            {!loading && grouped.map((group) => (
                group.items.length > 0 && (
                    <section className="pdm-collab-group" key={group.status}>
                        <h2>{group.title} ({group.items.length})</h2>
                        <p className="pdm-collab-group-note">{group.note}</p>
                        <ul className="pdm-collab-submissions">
                            {group.items.map((proposal) => {
                                const detail = describeProposal(proposal);
                                const reason = proposal.rejection_reason;
                                const isConfirming = confirming === proposal.id;
                                return (
                                    <li className="pdm-collab-submission" key={`${proposal.type}:${proposal.id}`}>
                                        <div className="pdm-collab-submission-head">
                                            <span className={`pdm-collab-tag is-${group.status}`}>
                                                {TYPE_LABEL[proposal.type] || proposal.type}
                                            </span>
                                            <span className="pdm-collab-submission-item">{proposal.item}</span>
                                            <span className="pdm-collab-submission-when">
                                                {formatWhen(proposal.created_at)}
                                            </span>
                                        </div>

                                        {detail && <p className="pdm-collab-submission-detail">{detail}</p>}

                                        {reason && (
                                            <p className="pdm-collab-submission-reason">
                                                <strong>Reviewer’s reason:</strong> {reason}
                                            </p>
                                        )}
                                        {/* A rejection with no reason is a gap worth naming rather
                                            than papering over with an empty space. */}
                                        {!reason && (group.status === 'rejected' || group.status === 'changes_requested') && (
                                            <p className="pdm-collab-submission-reason">
                                                No reason was recorded.
                                            </p>
                                        )}
                                        {proposal.review_note && group.status === 'approved' && (
                                            <p className="pdm-collab-submission-reason">
                                                <strong>Reviewer’s note:</strong> {proposal.review_note}
                                            </p>
                                        )}

                                        {group.status === 'pending' && (
                                            isConfirming ? (
                                                <div className="pdm-collab-confirm" role="group" aria-label="Confirm withdrawal">
                                                    <span>Withdraw this? It cannot be undone.</span>
                                                    <button
                                                        type="button"
                                                        className="pdm-collab-danger"
                                                        disabled={withdrawing === proposal.id}
                                                        onClick={() => withdraw(proposal)}
                                                    >
                                                        {withdrawing === proposal.id ? 'Withdrawing…' : 'Yes, withdraw'}
                                                    </button>
                                                    <button
                                                        type="button"
                                                        className="pdm-collab-ghost"
                                                        onClick={() => setConfirming(null)}
                                                    >
                                                        Keep it
                                                    </button>
                                                </div>
                                            ) : (
                                                <button
                                                    type="button"
                                                    className="pdm-collab-ghost"
                                                    onClick={() => { setConfirming(proposal.id); setNotice(null); }}
                                                >
                                                    Withdraw
                                                </button>
                                            )
                                        )}
                                    </li>
                                );
                            })}
                        </ul>
                    </section>
                )
            ))}

            {unknown.length > 0 && (
                <section className="pdm-collab-group">
                    <h2>Other ({unknown.length})</h2>
                    <p className="pdm-collab-group-note">
                        These carry a status this page does not recognise. They are listed so
                        nothing of yours is hidden.
                    </p>
                    <ul className="pdm-collab-submissions">
                        {unknown.map((proposal) => (
                            <li className="pdm-collab-submission" key={`${proposal.type}:${proposal.id}`}>
                                <div className="pdm-collab-submission-head">
                                    <span className="pdm-collab-tag">{TYPE_LABEL[proposal.type] || proposal.type}</span>
                                    <span className="pdm-collab-submission-item">{proposal.item}</span>
                                    <span className="pdm-collab-submission-when">{proposal.status}</span>
                                </div>
                            </li>
                        ))}
                    </ul>
                </section>
            )}

            {!loading && (
                <div className="pdm-collab-aside">
                    <p className="pdm-collab-aside-note">
                        <strong>Two kinds of contribution never appear here.</strong> “Support a
                        connection” and “Address a challenge” record a relationship between things
                        already on the map, and a relationship carries no review status — so those
                        take effect immediately and there is nothing to track or withdraw.
                    </p>
                    <Link className="pdm-collab-ghost" to="/collaborate">Make another contribution</Link>
                </div>
            )}
        </>
    );
};

export default MySubmissions;
