import React from 'react';
import { Link } from 'react-router-dom';

/**
 * The card every proposal form is drawn in, and the states it can be in.
 *
 * Taken from the design reference: a white card with a thin light border and
 * generous padding, the title top-left, fields in a two-column grid with the
 * label above each input, and a single solid-blue Submit centred at the foot.
 *
 * ── THE SUCCESS STATE REPLACES THE FORM ──────────────────────────────────────
 * It does not sit above it. Everything created here is `status: 'pending'` and
 * invisible on the map until a reviewer approves it, so the one thing a
 * contributor needs to be told is that submitting is not publishing. A green
 * line above a form still holding the values they just sent invites them to
 * press Submit again and collect a duplicate-name 422.
 *
 * `submitting` disables the button rather than replacing the card, so the
 * values stay on screen if the request fails.
 *
 * ── NOT EVERYTHING HERE IS REVIEWED, AND THIS MUST NOT PRETEND OTHERWISE ─────
 * Five of the seven forms create a NODE, which carries status 'pending' and is
 * invisible until a reviewer approves it. Two of them — "Support a connection"
 * and "Address a challenge" — create a RELATIONSHIP instead, and a relationship
 * has no status in this schema. Those take effect on the public map the moment
 * they are submitted, appear in no review queue, and cannot be withdrawn.
 *
 * `success.reviewed === false` says so plainly. Telling a contributor their
 * change is "awaiting review" when it is already live would be false, and it is
 * exactly the sentence that would stop them double-checking it.
 */
const ProposalForm = ({
    title,
    lede,
    children,
    onSubmit,
    canSubmit,
    submitting = false,
    submitLabel = 'Submit',
    submitNote = 'Submitted contributions are reviewed by a peer reviewer before they appear on the map.',
    formError = null,
    success = null,          // { label, description } once the API has accepted it
    onSubmitAnother = null,
    busyLabel = 'Submitting…',
}) => {
    if (success) {
        const reviewed = success.reviewed !== false;
        return (
            <div className="pdm-collab-done" role="status" aria-live="polite">
                <h1>{reviewed ? 'Submitted for review' : 'Recorded on the map'}</h1>
                <p className="pdm-collab-done-item">{success.label}</p>
                {reviewed ? (
                    <p>
                        {success.description || 'This is now pending review.'} It will not appear on
                        the map until a peer reviewer approves it. You can follow it — or withdraw
                        it while it is still pending — from your submissions.
                    </p>
                ) : (
                    <>
                        <p>{success.description}</p>
                        <div className="pdm-collab-panel pdm-collab-panel-warn">
                            <p>
                                <strong>This one took effect immediately.</strong> It records a
                                relationship between things already on the map, and the schema gives
                                a relationship no review status — so there is nothing for a reviewer
                                to approve, it does not appear in your submissions, and it cannot be
                                withdrawn from here. Check it reads the way you meant.
                            </p>
                        </div>
                    </>
                )}
                <div className="pdm-collab-done-actions">
                    {onSubmitAnother && (
                        <button type="button" className="pdm-collab-submit" onClick={onSubmitAnother}>
                            Submit another
                        </button>
                    )}
                    {reviewed && <Link className="pdm-collab-ghost" to="/collaborate/mine">My submissions</Link>}
                    <Link className="pdm-collab-ghost" to="/collaborate">Back to Collaborate</Link>
                </div>
            </div>
        );
    }

    return (
        <form
            className="pdm-collab-form-card"
            noValidate
            onSubmit={(event) => { event.preventDefault(); onSubmit(); }}
        >
            <h1>{title}</h1>
            {lede && <p className="pdm-collab-form-lede">{lede}</p>}

            {/* Above the fields, not beside the button: a message under a
                disabled control at the foot of a long card is off-screen. */}
            {formError && (
                <div className="pdm-collab-panel pdm-collab-panel-error" role="alert">
                    {formError}
                </div>
            )}

            <div className="pdm-collab-grid">{children}</div>

            <div className="pdm-collab-actions">
                <button
                    type="submit"
                    className="pdm-collab-submit"
                    disabled={!canSubmit || submitting}
                >
                    {submitting ? busyLabel : submitLabel}
                </button>
                <p className="pdm-collab-actions-note">{submitNote}</p>
            </div>
        </form>
    );
};

export default ProposalForm;
