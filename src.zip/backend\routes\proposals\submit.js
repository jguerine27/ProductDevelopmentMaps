'use strict';

const express = require('express');
const { asyncHandler, notFound, AppError } = require('../../middleware/errorHandler');
const { getWriteSession, recordToObject } = require('../../db');
const v = require('../../services/validation');
const proposals = require('../../services/proposals');

const router = express.Router();

/**
 * §3 — anyone signed in may propose. requireAuth is applied by the parent
 * router (routes/proposals/index.js), not here, so a route added to this file
 * cannot end up public.
 *
 * Everything created here carries status 'pending', created_by from the SESSION
 * and created_at. `created_by` is never read from the body: a caller who sends
 * { created_by: 'someone-else' } is simply ignored.
 */

/** Uniform provenance for every proposal, and the guarantee it is server-set. */
const provenance = (req) => ({ createdBy: req.user.id });

const PROVENANCE_SET = `
    n.status     = 'pending',
    n.created_by = $createdBy,
    n.created_at = datetime()
`;

async function runWrite(cypher, params) {
    const session = getWriteSession();
    try {
        const result = await session.executeWrite((tx) => tx.run(cypher, params));
        return result.records.length ? recordToObject(result.records[0]) : null;
    } finally {
        await session.close();
    }
}

const created = (res, type, row) => res.status(201).json({ proposal: { type, ...row } });

// ── Blocks ───────────────────────────────────────────────────────────────────
router.post('/blocks', asyncHandler(async (req, res) => {
    const name = v.requireString(req.body, 'name');
    const level = v.requireEnum(req.body, 'level', v.LEVELS);
    const maps = v.requireStringArray(req.body, 'maps');
    const relatedApproach = v.requireString(req.body, 'related_approach');
    const color = v.optionalString(req.body, 'color', { max: 32 });
    const citations = v.optionalString(req.body, 'citations');

    await v.assertMapCodesExist(maps);

    // MERGE, not CREATE: Block.name is unique, and a plain CREATE would surface
    // a raw ConstraintValidationFailed rather than a message anyone can act on.
    const existing = await runWrite(
        'MATCH (n:Block {name: $name}) RETURN n.status AS status', { name });
    if (existing) {
        throw v.invalid(`A block named "${name}" already exists (status: ${existing.status}).`);
    }

    const row = await runWrite(`
        CREATE (n:Block {name: $name})
        SET n.level            = $level,
            n.maps             = $maps,
            n.related_approach = $relatedApproach,
            n.color            = $color,
            n.citations        = $citations,
            n.tags             = '',
            ${PROVENANCE_SET}
        RETURN elementId(n) AS id, n.name AS item, n.status AS status
    `, { name, level, maps, relatedApproach, color, citations, ...provenance(req) });

    created(res, 'blocks', row);
}));

// ── Links ────────────────────────────────────────────────────────────────────
router.post('/links', asyncHandler(async (req, res) => {
    const source = v.requireString(req.body, 'source');
    const target = v.requireString(req.body, 'target');
    const ltype = v.requireEnum(req.body, 'ltype', v.LTYPES);
    const maps = v.requireStringArray(req.body, 'maps');

    await v.assertMapCodesExist(maps);
    // Endpoints exist, and every map on the link is on both of them.
    await v.assertLinkEndpointsAndMaps({ source, target, maps });

    const existing = await runWrite(`
        MATCH (n:Link {source: $source, target: $target, ltype: $ltype})
        RETURN n.status AS status
    `, { source, target, ltype });
    if (existing) {
        throw v.invalid(
            `A link "${source}" -> "${target}" [${ltype}] already exists (status: ${existing.status}).`);
    }

    // The HAS_LINK edges are created alongside the node: a Link without them is
    // invisible to graphQuery.js, which traverses rather than matching on the
    // source/target strings.
    const row = await runWrite(`
        MATCH (s:Block {name: $source})
        MATCH (t:Block {name: $target})
        CREATE (n:Link {source: $source, target: $target, ltype: $ltype})
        SET n.maps            = $maps,
            n.reference_count = 0,
            ${PROVENANCE_SET}
        MERGE (s)-[:HAS_LINK]->(n)
        MERGE (n)-[:HAS_LINK]->(t)
        RETURN elementId(n) AS id,
               n.source + ' -> ' + n.target + ' [' + n.ltype + ']' AS item,
               n.status AS status
    `, { source, target, ltype, maps, ...provenance(req) });

    created(res, 'links', row);
}));

// ── References ───────────────────────────────────────────────────────────────
router.post('/references', asyncHandler(async (req, res) => {
    // `author` is the short label printed on the cartographies ("Mhenni et al.")
    // and half the (author, year) key. `authors_full` is the full list the
    // bibliography renders. They are two fields, not one — see populate-database.js.
    const author = v.requireString(req.body, 'author');
    const year = v.requireYear(req.body);
    const authorsFull = v.optionalString(req.body, 'authors_full');
    const title = v.requireString(req.body, 'title', { max: v.MAX_TEXT });
    const type = v.requireEnum(req.body, 'type', v.REFERENCE_TYPES);

    const existing = await runWrite(
        'MATCH (n:Reference {author: $author, year: $year}) RETURN n.status AS status',
        { author, year });
    if (existing) {
        throw v.invalid(`A reference "${author} ${year}" already exists (status: ${existing.status}).`);
    }

    const row = await runWrite(`
        CREATE (n:Reference {author: $author, year: $year})
        SET n.authors_full = $authorsFull,
            n.title        = $title,
            n.type         = $type,
            n.journal      = $journal,
            n.conference   = $conference,
            n.volume       = $volume,
            n.issue        = $issue,
            n.pages        = $pages,
            n.institution  = $institution,
            n.publisher    = $publisher,
            n.editors      = $editors,
            n.book_title   = $bookTitle,
            n.doi          = $doi,
            ${PROVENANCE_SET}
        RETURN elementId(n) AS id, n.author + ' ' + n.year AS item, n.status AS status
    `, {
        author, year, authorsFull, title, type,
        journal: v.optionalString(req.body, 'journal'),
        conference: v.optionalString(req.body, 'conference'),
        volume: v.optionalString(req.body, 'volume', { max: 32 }),
        issue: v.optionalString(req.body, 'issue', { max: 32 }),
        pages: v.optionalString(req.body, 'pages', { max: 32 }),
        institution: v.optionalString(req.body, 'institution'),
        publisher: v.optionalString(req.body, 'publisher'),
        editors: v.optionalString(req.body, 'editors'),
        bookTitle: v.optionalString(req.body, 'book_title'),
        doi: v.optionalDoi(req.body),
        ...provenance(req),
    });

    created(res, 'references', row);
}));

// ── Link-references ──────────────────────────────────────────────────────────
/**
 * Attaching an existing paper to a link is a different act from creating the
 * paper, which is why this is not part of /references. It is also where
 * asterisk, grey and the per-reference maps live — the flags that decide how the
 * evidence is drawn.
 *
 * ── THE EDGE IS A PROPOSAL, NOT AN IMMEDIATE WRITE ───────────────────────────
 * This used to create the SUPPORTED_BY edge live, on the reasoning that a
 * relationship cannot carry a status because nothing else in the schema puts one
 * on a relationship. Neo4j takes relationship properties without difficulty, and
 * the consequence of not having one was that any signed-in contributor could
 * publish a citation to the public map with no review — including attaching a
 * real, approved paper to a connection it does not support, which no amount of
 * checking the Reference NODE's status would catch.
 *
 * So the edge is created 'pending' with the same provenance every node proposal
 * carries, and services/graphQuery.js filters on it. Link.reference_count counts
 * APPROVED citations only, so proposing one does not move it.
 */
router.post('/link-references', asyncHandler(async (req, res) => {
    const link = req.body && req.body.link;
    const reference = req.body && req.body.reference;
    if (!link || typeof link !== 'object') {
        throw v.invalid('"link" is required as { source, target, ltype }.');
    }
    if (!reference || typeof reference !== 'object') {
        throw v.invalid('"reference" is required as { author, year }.');
    }

    const linkKey = {
        source: v.requireString(link, 'source'),
        target: v.requireString(link, 'target'),
        ltype: v.requireEnum(link, 'ltype', v.LTYPES),
    };
    const refKey = {
        author: v.requireString(reference, 'author'),
        year: v.requireYear(reference),
    };
    const maps = v.requireStringArray(req.body, 'maps');
    const asterisk = v.requireBoolean(req.body, 'asterisk', false);
    const grey = v.requireBoolean(req.body, 'grey', false);

    await v.assertMapCodesExist(maps);
    // Link and reference both exist, and maps ⊆ link.maps.
    await v.assertLinkReferenceMaps({ link: linkKey, reference: refKey, maps });

    /**
     * CREATE, not MERGE — and a 409 when the citation already exists.
     *
     * MERGE was safe while the edge had no review state. It is not now: it would
     * match an already-APPROVED citation and overwrite its asterisk, grey and
     * maps while resetting its status to 'pending', letting any contributor
     * silently rewrite and un-approve reviewed evidence. Refusing is the same
     * answer a duplicate block or reference gets.
     */
    const existing = await runWrite(`
        MATCH (:Link {source: $source, target: $target, ltype: $ltype})
              -[s:SUPPORTED_BY]->(:Reference {author: $author, year: $year})
        RETURN s.status AS status
    `, { ...linkKey, ...refKey });
    if (existing) {
        throw new AppError(409, 'LINK_REFERENCE_EXISTS',
            `"${refKey.author} ${refKey.year}" already supports `
            + `"${linkKey.source}" -> "${linkKey.target}" [${linkKey.ltype}] `
            + `(status: ${existing.status}).`);
    }

    const row = await runWrite(`
        MATCH (l:Link {source: $source, target: $target, ltype: $ltype})
        MATCH (r:Reference {author: $author, year: $year})
        CREATE (l)-[s:SUPPORTED_BY]->(r)
        SET s.asterisk   = $asterisk,
            s.grey       = $grey,
            s.maps       = $maps,
            s.status     = 'pending',
            s.created_by = $createdBy,
            s.created_at = datetime()
        WITH l, r, s
        // reference_count is the count of DISTINCT APPROVED citations, recomputed
        // from the graph rather than incremented — the same rule
        // populate-database.js follows. A pending proposal must not move it, so
        // the figure returned here is the public one and is unchanged.
        OPTIONAL MATCH (l)-[s2:SUPPORTED_BY]->(x:Reference)
        WHERE s2.status = 'approved'
        WITH l, r, s, count(DISTINCT x) AS refCount
        SET l.reference_count = refCount
        RETURN elementId(s) AS id,
               l.source + ' -> ' + l.target + ' [' + l.ltype + '] : ' + r.author + ' ' + r.year AS item,
               s.status AS status,
               refCount AS reference_count
    `, { ...linkKey, ...refKey, maps, asterisk, grey, ...provenance(req) });

    created(res, 'link-references', row);
}));

// ── Challenges ───────────────────────────────────────────────────────────────
router.post('/challenges', asyncHandler(async (req, res) => {
    const name = v.requireString(req.body, 'name');
    const description = v.requireString(req.body, 'description', { max: v.MAX_TEXT });

    const existing = await runWrite(
        'MATCH (n:Challenge {name: $name}) RETURN n.status AS status', { name });
    if (existing) {
        throw v.invalid(`A challenge named "${name}" already exists (status: ${existing.status}).`);
    }

    const row = await runWrite(`
        CREATE (n:Challenge {name: $name})
        SET n.description = $description,
            ${PROVENANCE_SET}
        RETURN elementId(n) AS id, n.name AS item, n.status AS status
    `, { name, description, ...provenance(req) });

    created(res, 'challenges', row);
}));

/**
 * Recording that a block addresses a challenge.
 *
 * Same story as link-references: the SOLVED_BY edge used to be created live,
 * which put an unreviewed claim on the public /api/challenges routes at once.
 * It is now a pending proposal like everything else.
 */
router.post('/challenge-blocks', asyncHandler(async (req, res) => {
    const challenge = v.requireString(req.body, 'challenge');
    const block = v.requireString(req.body, 'block');

    const row = await runWrite(`
        OPTIONAL MATCH (c:Challenge {name: $challenge})
        OPTIONAL MATCH (b:Block {name: $block})
        RETURN c IS NOT NULL AS hasChallenge, b IS NOT NULL AS hasBlock
    `, { challenge, block });
    if (!row.hasChallenge) throw v.invalid(`No challenge named "${challenge}".`);
    if (!row.hasBlock) throw v.invalid(`No block named "${block}".`);

    /**
     * A duplicate is a 409, not a silent success.
     *
     * MERGE meant re-submitting an existing pairing answered 201 and changed
     * nothing, so a contributor could not tell whether their contribution had
     * been recorded or was already there, and the frontend's duplicate check was
     * the only one in the system. It now matches how duplicate blocks,
     * references and challenges are handled.
     */
    const existing = await runWrite(`
        MATCH (:Challenge {name: $challenge})-[s:SOLVED_BY]->(:Block {name: $block})
        RETURN s.status AS status
    `, { challenge, block });
    if (existing) {
        throw new AppError(409, 'CHALLENGE_BLOCK_EXISTS',
            `"${block}" is already recorded as addressing "${challenge}" (status: ${existing.status}).`);
    }

    const linked = await runWrite(`
        MATCH (c:Challenge {name: $challenge})
        MATCH (b:Block {name: $block})
        CREATE (c)-[s:SOLVED_BY]->(b)
        SET s.status     = 'pending',
            s.created_by = $createdBy,
            s.created_at = datetime()
        RETURN elementId(s) AS id,
               c.name + ' -> ' + b.name AS item,
               s.status AS status
    `, { challenge, block, ...provenance(req) });

    created(res, 'challenge-blocks', linked);
}));

// ── Maps ─────────────────────────────────────────────────────────────────────
router.post('/maps', asyncHandler(async (req, res) => {
    const code = v.requireString(req.body, 'code', { max: 16 });
    const label = v.requireString(req.body, 'label');
    const description = v.optionalString(req.body, 'description');
    const sourceReference = req.body && req.body.source_reference;

    const existing = await runWrite('MATCH (n:Map {code: $code}) RETURN n.status AS status', { code });
    if (existing) {
        throw v.invalid(`A map with code "${code}" already exists (status: ${existing.status}).`);
    }

    const row = await runWrite(`
        CREATE (n:Map {code: $code})
        SET n.label       = $label,
            n.description = $description,
            ${PROVENANCE_SET}
        RETURN elementId(n) AS id, n.code + ' (' + n.label + ')' AS item, n.status AS status
    `, { code, label, description, ...provenance(req) });

    // The paper the cartography comes from, if given. Optional by design: a
    // proposed map may predate its own publication.
    if (sourceReference && typeof sourceReference === 'object') {
        const author = v.requireString(sourceReference, 'author');
        const year = v.requireYear(sourceReference);
        const attached = await runWrite(`
            MATCH (m:Map {code: $code})
            MATCH (r:Reference {author: $author, year: $year})
            MERGE (m)-[:SOURCED_FROM]->(r)
            RETURN r.author + ' ' + r.year AS item
        `, { code, author, year });
        if (!attached) {
            throw v.invalid(`No reference "${author} ${year}" exists to source this map from.`);
        }
        row.source_reference = attached.item;
    }

    created(res, 'maps', row);
}));

// ── Mine ─────────────────────────────────────────────────────────────────────
router.get('/mine', asyncHandler(async (req, res) => {
    const list = await proposals.listProposals({ createdBy: req.user.id });
    res.json({ proposals: list, meta: { counts: { proposals: list.length } } });
}));

// ── Withdraw ─────────────────────────────────────────────────────────────────
/**
 * Own proposals only, pending only, both enforced inside the query so there is
 * no gap between checking and deleting. A proposal already approved is map
 * content and is deleted through the manage routes, by a reviewer.
 */
router.delete('/:type/:id', asyncHandler(async (req, res) => {
    let type;
    try {
        type = proposals.resolveType(req.params.type);
    } catch (err) {
        throw notFound('UNKNOWN_PROPOSAL_TYPE',
            `Unknown proposal type "${req.params.type}". Valid: ${err.knownTypes.join(', ')}.`);
    }

    const item = await proposals.deleteOwnProposal(type.slug, req.params.id, req.user.id);
    if (!item) {
        // One message for "not found", "not yours" and "not pending" alike:
        // distinguishing them would let a caller enumerate other people's
        // proposals by id.
        throw notFound('PROPOSAL_NOT_FOUND',
            'No pending proposal of yours with that id. It may have been reviewed already.');
    }
    res.json({ withdrawn: { type: type.slug, item } });
}));

module.exports = router;
