import React from 'react';
import { Link } from 'react-router-dom';

/**
 * The Collaborate hub: one card per kind of contribution.
 *
 * ── THE ORDER IS THE POINT ───────────────────────────────────────────────────
 * "Add something new" comes first, because a first-time contributor almost
 * always has a concept, a connection or a paper in mind. The two relationship
 * forms come second and are grouped on their own panel: they attach existing
 * things to each other and mean nothing to somebody who has not yet found the
 * entries they want to relate.
 *
 * ── CARTOGRAPHY IS DELIBERATELY NOT A CARD ───────────────────────────────────
 * A new cartography is a whole new map for a product type the three published
 * ones do not cover — a rare, heavyweight act, and the only proposal with a
 * field (the code) that cannot be changed after approval. Given equal weight in
 * the grid it reads as a sixth ordinary option and invites someone to file a
 * block proposal as a map. It stays reachable, as one quiet line.
 */

const NEW_CARDS = [
    {
        to: '/collaborate/block',
        title: 'Block',
        note: 'A concept or technique — an approach, process, method or tool.',
    },
    {
        to: '/collaborate/connection',
        title: 'Link',
        note: 'A relationship between two blocks that are already on the map.',
    },
    {
        to: '/collaborate/reference',
        title: 'Reference',
        note: 'A published source: a paper, book, thesis, report or standard.',
    },
    {
        to: '/collaborate/challenge',
        title: 'Challenge',
        note: 'An industrial difficulty the map should help address.',
    },
];

const RELATE_CARDS = [
    {
        to: '/collaborate/support',
        title: 'Support a connection',
        note: 'Attach an existing reference to an existing connection as evidence.',
    },
    {
        to: '/collaborate/address',
        title: 'Address a challenge',
        note: 'Record that an existing block helps with an existing challenge.',
    },
];

const Card = ({ to, title, note }) => (
    <Link className="pdm-collab-card" to={to}>
        <span className="pdm-collab-card-title">{title}</span>
        <span className="pdm-collab-card-note">{note}</span>
    </Link>
);

const CollaborateHub = () => (
    <>
        <div className="pdm-collab-head">
            <p className="pdm-collab-eyebrow">Collaborate</p>
            <h1>Contribute to the cartographies</h1>
            <p className="pdm-collab-lede">
                Propose an addition to the map. Everything submitted here goes to a peer
                reviewer first and stays invisible on the map until it is approved.
            </p>
        </div>

        <section className="pdm-collab-group" aria-labelledby="pdm-collab-group-new">
            <h2 id="pdm-collab-group-new">Add something new</h2>
            <p className="pdm-collab-group-note">
                A concept, a relationship, a source, or a difficulty from practice.
            </p>
            <div className="pdm-collab-cards">
                {NEW_CARDS.map((card) => <Card key={card.to} {...card} />)}
            </div>
            {/* <p className="pdm-collab-rare">
                Covering a product type none of the three published cartographies reach?
                You can <Link to="/collaborate/cartography">propose an entire new
                cartography</Link> — rare, and its code cannot be changed once approved.
            </p> */}
        </section>

        <section
            className="pdm-collab-group pdm-collab-group-secondary"
            aria-labelledby="pdm-collab-group-relate"
        >
            <h2 id="pdm-collab-group-relate">Support existing map</h2>
            {/* <p className="pdm-collab-group-note">
                Both of these relate things already on the map to each other. Nothing new
                is created — if what you want to point at is not there yet, propose it above
                first.
            </p> */}
            <div className="pdm-collab-cards">
                {RELATE_CARDS.map((card) => <Card key={card.to} {...card} />)}
            </div>
        </section>

        <div className="pdm-collab-aside">
            <p className="pdm-collab-aside-note">
                See already proposed submissions
            </p>
            <Link className="pdm-collab-ghost" to="/collaborate/mine">My submissions</Link>
        </div>
    </>
);

export default CollaborateHub;
