import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import '../auth/AuthScreens.css';

/**
 * The reviewer area — a placeholder.
 *
 * The review queue itself is a later task and is explicitly out of scope here.
 * This exists so /review is a real destination: RequireReviewer needs something
 * to guard, and a reviewer who follows the Review link should land on a page
 * that says where they are rather than a 404.
 *
 * A non-reviewer never sees this — RequireReviewer shows them the explanatory
 * page instead. That is a courtesy; the API enforces the rule.
 */
const Review = () => {
    const { user } = useAuth();

    return (
        <div className="pdm-auth-notice">
            <h1>Review queue</h1>
            <p>
                Signed in as <strong>{user.display_name}</strong> — peer reviewer
                {user.orcid ? ` (ORCID ${user.orcid})` : ''}.
            </p>
            <p>
                The review queue is not built yet. When it is, proposed blocks, links,
                references, challenges and cartographies awaiting a decision will appear
                here.
            </p>
            <div className="pdm-auth-notice-actions">
                <Link className="pdm-auth-button" to="/map">Back to the map</Link>
            </div>
        </div>
    );
};

export default Review;
