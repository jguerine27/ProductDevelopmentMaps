import React, { useMemo, useState } from 'react';
import apiClient from '../../api/client';
import { useCollaborateData } from '../CollaborateData';
import { mapApiError } from '../apiErrors';
import ProposalForm from '../ProposalForm';
import { TextField, TextAreaField, Note, showError } from '../fields';

/**
 * Propose a challenge — an industrial difficulty the map should help address.
 *
 * POST /api/proposals/challenges   { name, description }
 *
 * ── THE HOUSE STYLE IS SPECIFIC, SO IT IS SHOWN RATHER THAN DESCRIBED ────────
 * The fourteen existing challenges come from an interview study, and they are
 * written to a consistent pattern: the SUBJECT is the development structure, the
 * product or the engineering department — never a person — and the sentence
 * states a difficulty that structure has, with no invented consequence attached.
 *
 *   "The development structure is unable to reduce the number of physical
 *    prototypes built during development"
 *
 * Telling a contributor that in the abstract does not work; three real examples
 * do. They are read from GET /api/challenges rather than written out here, so
 * the samples stay correct as the set grows, and so this never contradicts the
 * data it is teaching from.
 */

const EMPTY = Object.freeze({ name: '', description: '' });

const ERROR_PATTERNS = [
    { test: /^A challenge named .* already exists/, field: 'name' },
];

/** How many worked examples to show. Enough to see the pattern, not a list. */
const EXAMPLE_COUNT = 3;

const ChallengeForm = () => {
    const { challenges, loading, error: metadataError } = useCollaborateData();

    const [values, setValues] = useState(EMPTY);
    const [errors, setErrors] = useState({});
    const [formError, setFormError] = useState(null);
    const [submitting, setSubmitting] = useState(false);
    const [success, setSuccess] = useState(null);

    const set = (field, value) => {
        setValues((prev) => ({ ...prev, [field]: value }));
        setErrors((prev) => (prev[field] ? { ...prev, [field]: undefined } : prev));
        setFormError(null);
    };

    /**
     * The examples with the most substantial descriptions, so the pattern is
     * visible. Sorted by name first so the choice is stable between renders
     * rather than reshuffling as the list arrives.
     */
    const examples = useMemo(() => {
        const withDescription = challenges.filter((c) => c.name && c.description);
        return [...withDescription]
            .sort((a, b) => a.name.localeCompare(b.name))
            .slice(0, EXAMPLE_COUNT);
    }, [challenges]);

    const trimmedName = values.name.trim();

    const nameClash = useMemo(() => {
        if (!trimmedName) return null;
        const lower = trimmedName.toLowerCase();
        return challenges.find((c) => c.name.toLowerCase() === lower) || null;
    }, [trimmedName, challenges]);

    const validate = () => {
        const next = {};
        if (!trimmedName) next.name = 'Give the challenge a short name.';
        else if (trimmedName.length > 300) next.name = `Names are capped at 300 characters (this is ${trimmedName.length}).`;
        else if (nameClash) next.name = `"${nameClash.name}" is already on the map.`;

        const description = values.description.trim();
        if (!description) next.description = 'Describe the difficulty in a full sentence.';
        else if (description.length > 4000) next.description = 'Descriptions are capped at 4000 characters.';
        return next;
    };

    const canSubmit = Object.keys(validate()).length === 0 && !loading;

    const submit = async () => {
        const found = validate();
        setErrors(found);
        if (Object.keys(found).length > 0) return;

        setSubmitting(true);
        setFormError(null);
        try {
            const response = await apiClient.post('/api/proposals/challenges', {
                name: trimmedName,
                description: values.description.trim(),
            });
            const proposal = response.data?.proposal || {};
            setSuccess({
                label: `Challenge — ${proposal.item || trimmedName}`,
                description: 'Once approved, blocks can be recorded as addressing it.',
            });
        } catch (err) {
            const { field, message } = mapApiError(err, { patterns: ERROR_PATTERNS });
            if (field) setErrors((prev) => ({ ...prev, [field]: message }));
            else setFormError(message);
        } finally {
            setSubmitting(false);
        }
    };

    const reset = () => {
        setValues(EMPTY);
        setErrors({});
        setFormError(null);
        setSuccess(null);
    };

    return (
        <ProposalForm
            title="Propose a challenge"
            lede="A challenge is a difficulty seen in industrial practice that the cartographies should help with. The existing ones come from an interview study, and new ones should read the same way."
            onSubmit={submit}
            canSubmit={canSubmit}
            submitting={submitting}
            formError={formError || metadataError}
            success={success}
            onSubmitAnother={reset}
        >
            <Note tone="info">
                <p>
                    <strong>How the existing challenges are written.</strong> The subject is the
                    development structure, the product or the engineering department — not a
                    person, and not a team. The sentence says what that thing struggles with, and
                    stops there: no consequence is added that the interviews did not report.
                </p>
                {examples.length > 0 && (
                    <ul className="pdm-collab-ltypes">
                        {examples.map((challenge) => (
                            <li key={challenge.name} style={{ gridTemplateColumns: '1fr' }}>
                                <span>
                                    <strong>{challenge.name}</strong> — “{challenge.description}”
                                </span>
                            </li>
                        ))}
                    </ul>
                )}
            </Note>

            <TextField
                label="Name"
                required
                wide
                autoFocus
                maxLength={300}
                value={values.name}
                onChange={(value) => set('name', value)}
                placeholder="Physical prototype dependency"
                error={showError(errors.name, nameClash ? `"${nameClash.name}" is already on the map.` : null)}
                hint="A few words naming the difficulty — this is the label shown when the challenge is selected on the map."
            />

            <TextAreaField
                label="Description"
                required
                rows={4}
                maxLength={4000}
                value={values.description}
                onChange={(value) => set('description', value)}
                placeholder="The development structure is unable to reduce the number of physical prototypes built during development"
                error={errors.description}
                hint="One sentence, in the style above. Say what is difficult, not what should be done about it — the map's job is to answer that."
            />
        </ProposalForm>
    );
};

export default ChallengeForm;
