'use strict';

const { getReadSession, getWriteSession, recordToObject } = require('../db');
const { DELETED_USER } = require('./users');

/**
 * Data-subject rights: export and erasure.
 *
 * These are obligations, not features. The deployment is subject to Quebec
 * Law 25 and in all likelihood GDPR, both of which give a person the right to
 * obtain what is held about them and to have it erased.
 *
 * ── WRITTEN TO OUTLIVE THIS SPRINT ───────────────────────────────────────────
 * Both functions iterate over ARTEFACT_TYPES rather than naming labels inline.
 * Ratings, comments and tag votes ship next sprint; when they do, they are added
 * to that one table and both endpoints cover them without being rewritten. A
 * fixed list here would mean the first person to exercise their rights after the
 * method card ships gets an incomplete export — a compliance failure produced by
 * a refactor nobody remembered to do.
 *
 * ── ERASURE ANONYMISES, IT DOES NOT DELETE CONTENT ───────────────────────────
 * The AppUser node goes; created_by / approved_by / rejected_by referencing it
 * become 'deleted-user'. Approved content the person proposed stays, because it
 * is map content now rather than personal data, and destroying it would punish
 * everyone else for one person's withdrawal. The review trail stays intact but
 * unattributed, which is what keeps a past approval auditable without naming
 * someone who has left.
 *
 * This is also why identity is a RELATIONSHIP for ratings and comments —
 * (:AppUser)-[:WROTE]->(:Comment) rather than comment.author_id. Severing an
 * edge leaves the text; clearing a property would leave a dangling identifier.
 */

/**
 * Every content label that can carry a provenance stamp.
 *
 * The label is interpolated into Cypher below, so this list is also the
 * allow-list that makes that safe. It is a hard-coded constant and no
 * user-supplied value ever reaches it — see the note in buildLabelQuery.
 */
const ARTEFACT_TYPES = Object.freeze([
    { label: 'Block', key: 'name' },
    { label: 'Link', key: 'source' },
    { label: 'Reference', key: 'author' },
    { label: 'Challenge', key: 'name' },
    { label: 'Map', key: 'code' },
    // Next sprint, when the method-card write surface lands, add:
    //   { label: 'Rating',  key: 'id' },
    //   { label: 'Comment', key: 'id' },
    // Nothing else in this file needs to change.
]);

const PROVENANCE_FIELDS = Object.freeze(['created_by', 'approved_by', 'rejected_by']);

/**
 * Labels are not parameterisable in Cypher, so this is the one place a value is
 * interpolated. It is safe only because `label` comes from ARTEFACT_TYPES above,
 * never from a request. The assertion makes that a runtime guarantee rather than
 * a convention — the old nodes.js interpolated a caller-supplied label straight
 * into `MATCH (n:${label})`, which is exactly the hole this prevents.
 */
function assertKnownLabel(label) {
    if (!ARTEFACT_TYPES.some((t) => t.label === label)) {
        throw new Error(`Refusing to interpolate unknown label: ${label}`);
    }
    return label;
}

/** A human-readable handle for an artefact, so an export is legible. */
const describeExpression = (alias) =>
    `coalesce(${alias}.name, ${alias}.code, ` +
    `CASE WHEN ${alias}.source IS NOT NULL THEN ${alias}.source + ' -> ' + ${alias}.target + ' [' + ${alias}.ltype + ']' END, ` +
    `CASE WHEN ${alias}.author IS NOT NULL THEN ${alias}.author + ' ' + ${alias}.year END, ` +
    `${alias}.id, '(unnamed)')`;

/**
 * Everything held about one user, as JSON.
 * @returns {Promise<object>}
 */
async function exportUserData(userId) {
    const session = getReadSession();
    try {
        const account = await session.executeRead((tx) => tx.run(`
            MATCH (u:AppUser {id: $userId})
            RETURN u.id AS id, u.provider AS provider, u.provider_uid AS provider_uid,
                   u.display_name AS display_name, coalesce(u.orcid, '') AS orcid,
                   u.role AS role, toString(u.created_at) AS created_at,
                   toString(u.last_seen_at) AS last_seen_at,
                   coalesce(u.consent_version, '') AS consent_version,
                   toString(u.consent_at) AS consent_at
        `, { userId }));

        const submitted = [];
        const reviewed = [];

        for (const { label } of ARTEFACT_TYPES) {
            assertKnownLabel(label);

            const mine = await session.executeRead((tx) => tx.run(`
                MATCH (n:${label} {created_by: $userId})
                RETURN ${describeExpression('n')} AS item,
                       n.status AS status,
                       toString(n.created_at) AS created_at,
                       coalesce(n.review_note, '') AS review_note,
                       coalesce(n.rejection_reason, '') AS rejection_reason
                ORDER BY item
            `, { userId }));
            mine.records.forEach((r) => submitted.push({ type: label, ...recordToObject(r) }));

            const judged = await session.executeRead((tx) => tx.run(`
                MATCH (n:${label})
                WHERE n.approved_by = $userId OR n.rejected_by = $userId
                RETURN ${describeExpression('n')} AS item,
                       n.status AS status,
                       CASE WHEN n.approved_by = $userId THEN 'approved' ELSE 'rejected' END AS decision,
                       toString(coalesce(n.approved_at, n.rejected_at)) AS decided_at,
                       coalesce(n.review_note, '') AS review_note,
                       coalesce(n.rejection_reason, '') AS rejection_reason
                ORDER BY item
            `, { userId }));
            judged.records.forEach((r) => reviewed.push({ type: label, ...recordToObject(r) }));
        }

        return {
            exported_at: new Date().toISOString(),
            account: account.records.length ? recordToObject(account.records[0]) : null,
            submitted,
            reviewed,
            // Stated explicitly so a reader can tell the difference between "we
            // hold none of this" and "we forgot to include it".
            notes: [
                'Ratings, comments and tags are not yet implemented; none are held for any user.',
                'No email address, IP address or user agent is stored by this application.',
            ],
        };
    } finally {
        await session.close();
    }
}

/**
 * Erase the account, keep the content, unattribute the trail.
 *
 * One transaction: a partial erasure that removed the AppUser but left
 * created_by pointing at a vanished id would be worse than either outcome, and
 * would leave a dangling identifier in exactly the field the regulation cares
 * about.
 */
async function eraseUser(userId) {
    const session = getWriteSession();
    try {
        return await session.executeWrite(async (tx) => {
            const summary = { anonymised: {} };

            for (const { label } of ARTEFACT_TYPES) {
                assertKnownLabel(label);
                const counts = {};
                for (const field of PROVENANCE_FIELDS) {
                    const res = await tx.run(`
                        MATCH (n:${label}) WHERE n.${field} = $userId
                        SET n.${field} = $sentinel
                        RETURN count(n) AS n
                    `, { userId, sentinel: DELETED_USER });
                    const n = res.records[0].get('n').toInt();
                    if (n > 0) counts[field] = n;
                }
                if (Object.keys(counts).length > 0) summary.anonymised[label] = counts;
            }

            // DETACH so any relationship added later — RATED, WROTE,
            // FOUND_HELPFUL, TAGGED — goes with the node rather than blocking
            // the delete. The Rating and Comment nodes themselves are severed,
            // not destroyed: their text survives anonymised, which is what
            // erasure requires without deleting content other readers rely on.
            const deleted = await tx.run(`
                MATCH (u:AppUser {id: $userId})
                DETACH DELETE u
                RETURN count(u) AS n
            `, { userId });

            summary.account_deleted = deleted.records[0].get('n').toInt() > 0;
            return summary;
        });
    } finally {
        await session.close();
    }
}

module.exports = { ARTEFACT_TYPES, PROVENANCE_FIELDS, exportUserData, eraseUser };
