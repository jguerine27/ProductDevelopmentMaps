'use strict';

const { getReadSession, getWriteSession, recordToObject } = require('../db');

/**
 * Shared machinery for the proposal and review routes.
 *
 * ── THE TYPE ALLOW-LIST IS A SECURITY CONTROL ────────────────────────────────
 * Routes address proposals as /api/proposals/:type/:id, and `type` selects a
 * Cypher label or relationship type. Neither can be bound as a parameter, so it
 * is interpolated — and the ONLY thing making that safe is that :type is
 * resolved through PROPOSAL_TYPES below and rejected if absent.
 *
 * The old nodes.js did `MATCH (n:${label})` with a caller-supplied label and no
 * allow-list, which is a Cypher-injection hole. resolveType() is the fix, and
 * every interpolation in this file and in routes/proposals goes through it.
 * Everything else — every value — is a bound parameter.
 *
 * ── IDENTITY ─────────────────────────────────────────────────────────────────
 * Blocks, Links, References, Challenges and Maps predate this feature and are
 * keyed by their own natural keys, not by a UUID. Rather than add an id property
 * to five node types, a proposal is addressed by `elementId(n)`, which Neo4j
 * supplies for free and which is stable for the life of the node. It is opaque
 * to the client, which is appropriate: a proposal reference should not be
 * guessable or enumerable.
 *
 * ── TWO OF THE SEVEN TYPES ARE RELATIONSHIPS ─────────────────────────────────
 * SUPPORTED_BY (a paper supports a connection) and SOLVED_BY (a block addresses
 * a challenge) are edges, not nodes. They used to carry no status at all, which
 * meant a contributor's assertion went live on the public map the moment it was
 * posted — see the note on PROPOSAL_TYPES below. They now carry the same
 * status/created_by/created_at as every node type, and elementId() addresses a
 * relationship exactly as it addresses a node, so the whole lifecycle —
 * proposal, review queue, approve, reject, withdraw — works for both without a
 * second mechanism.
 *
 * The only structural difference is the MATCH pattern and, for SUPPORTED_BY, a
 * cascade: Link.reference_count is a stored count of APPROVED citations, so it
 * has to be recomputed whenever one is approved, rejected or withdrawn.
 */

/**
 * type slug -> how to match it, and how to describe it.
 * `label`, `match` and the cascades are interpolated into Cypher. Nothing here
 * comes from a request.
 *
 * ── WHY THE RELATIONSHIPS NEEDED A STATUS ────────────────────────────────────
 * An earlier revision reasoned that "SUPPORTED_BY carries no status of its own,
 * since nothing else in the schema puts one on a relationship". Neo4j takes
 * properties on relationships without difficulty; that was an argument from
 * consistency, not from capability, and it left a hole: any signed-in
 * contributor could attach a reference to any connection and have the citation
 * render on the public, unauthenticated map immediately.
 *
 * Putting the status on the RELATIONSHIP rather than on the Reference node is
 * the part that matters. A status on the node alone would stop invented text
 * appearing, but not the more damaging case: attaching a real, approved paper to
 * a connection it does not support publishes a false claim using a legitimate
 * source. A reference is a fact about the world; a SUPPORTED_BY edge is an
 * assertion that this paper supports this connection, and the assertion is the
 * reviewable thing.
 */
const PROPOSAL_TYPES = Object.freeze({
    blocks: Object.freeze({ kind: 'node', label: 'Block', describe: 'n.name' }),
    links: Object.freeze({
        kind: 'node',
        label: 'Link',
        describe: "n.source + ' -> ' + n.target + ' [' + n.ltype + ']'",
    }),
    references: Object.freeze({ kind: 'node', label: 'Reference', describe: "n.author + ' ' + n.year" }),
    challenges: Object.freeze({ kind: 'node', label: 'Challenge', describe: 'n.name' }),
    maps: Object.freeze({ kind: 'node', label: 'Map', describe: "n.code + ' (' + n.label + ')'" }),

    'link-references': Object.freeze({
        kind: 'relationship',
        rel: 'SUPPORTED_BY',
        match: '(src:Link)-[n:SUPPORTED_BY]->(dst:Reference)',
        describe: "src.source + ' -> ' + src.target + ' [' + src.ltype + '] : ' + dst.author + ' ' + dst.year",
        // Link.reference_count is the stored count of APPROVED citations, which
        // is what the detail panel shows when nothing is filtered. A status
        // change on any one edge moves it, so it is recomputed in the same query
        // rather than left to drift.
        cascade: `
            WITH src, dst, n
            OPTIONAL MATCH (src)-[s2:SUPPORTED_BY]->(x:Reference)
            WHERE s2.status = 'approved'
            WITH src, dst, n, count(DISTINCT x) AS refCount
            SET src.reference_count = refCount
        `,
        // The same recount, after the edge itself has gone — `n` no longer
        // exists, so the aliases differ.
        deleteCascade: `
            WITH src, item
            OPTIONAL MATCH (src)-[s2:SUPPORTED_BY]->(x:Reference)
            WHERE s2.status = 'approved'
            WITH src, item, count(DISTINCT x) AS refCount
            SET src.reference_count = refCount
        `,
    }),

    'challenge-blocks': Object.freeze({
        kind: 'relationship',
        rel: 'SOLVED_BY',
        match: '(src:Challenge)-[n:SOLVED_BY]->(dst:Block)',
        describe: "src.name + ' -> ' + dst.name",
        cascade: '',
        deleteCascade: '',
    }),
});

const PROPOSAL_TYPE_SLUGS = Object.freeze(Object.keys(PROPOSAL_TYPES));
const STATUSES = Object.freeze(['pending', 'approved', 'rejected', 'changes_requested']);

/** The relationship types, for callers that need to treat them differently. */
const RELATIONSHIP_TYPE_SLUGS = Object.freeze(
    PROPOSAL_TYPE_SLUGS.filter((slug) => PROPOSAL_TYPES[slug].kind === 'relationship')
);

/**
 * @returns {{slug: string, kind: string, label?: string, match?: string, describe: string}}
 * @throws {Error} for anything not on the allow-list — callers turn this into a 404.
 */
function resolveType(slug) {
    const entry = PROPOSAL_TYPES[slug];
    if (!entry) {
        const err = new Error(`Unknown proposal type "${slug}"`);
        err.knownTypes = PROPOSAL_TYPE_SLUGS;
        throw err;
    }
    return { slug, ...entry };
}

/** The MATCH that binds `n` to the artefact, whichever kind it is. */
const matchClause = (type) => (type.kind === 'relationship'
    ? `MATCH ${type.match}`
    : `MATCH (n:${type.label})`);

/** DETACH is for nodes; a relationship has nothing to detach. */
const deleteClause = (type) => (type.kind === 'relationship' ? 'DELETE n' : 'DETACH DELETE n');

/** Carried through a cascade so the projection can still name the artefact. */
const carry = (type) => (type.kind === 'relationship' ? 'src, dst, n' : 'n');

/** The projection every proposal read returns, so the shape is uniform. */
const proposalProjection = (type) => `
    elementId(n)                        AS id,
    '${type.slug}'                      AS type,
    ${type.describe}                    AS item,
    n.status                            AS status,
    n.created_by                        AS created_by,
    toString(n.created_at)              AS created_at,
    coalesce(n.approved_by, '')         AS approved_by,
    toString(n.approved_at)             AS approved_at,
    coalesce(n.rejected_by, '')         AS rejected_by,
    toString(n.rejected_at)             AS rejected_at,
    coalesce(n.review_note, '')         AS review_note,
    coalesce(n.rejection_reason, '')    AS rejection_reason,
    properties(n)                       AS properties
`;

/** One proposal by type and element id, or null. */
async function findProposal(slug, id) {
    const type = resolveType(slug);
    const session = getReadSession();
    try {
        const result = await session.executeRead((tx) => tx.run(`
            ${matchClause(type)} WHERE elementId(n) = $id
            RETURN ${proposalProjection(type)}
        `, { id }));
        return result.records.length ? recordToObject(result.records[0]) : null;
    } finally {
        await session.close();
    }
}

/**
 * List proposals across every type, optionally narrowed.
 * `status` and `type` are validated by the caller against the constants above.
 */
async function listProposals({ status = null, slug = null, createdBy = null } = {}) {
    const slugs = slug ? [slug] : PROPOSAL_TYPE_SLUGS;
    const session = getReadSession();
    const out = [];
    try {
        for (const s of slugs) {
            const type = resolveType(s);
            const result = await session.executeRead((tx) => tx.run(`
                ${matchClause(type)}
                WHERE ($status IS NULL OR n.status = $status)
                  AND ($createdBy IS NULL OR n.created_by = $createdBy)
                RETURN ${proposalProjection(type)}
                ORDER BY n.created_at DESC, item
            `, { status, createdBy }));
            result.records.forEach((r) => out.push(recordToObject(r)));
        }
    } finally {
        await session.close();
    }
    // Newest first across types; created_at is an ISO string so it sorts lexically.
    return out.sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || '')));
}

/**
 * Approve in place.
 *
 * SET, never delete-and-recreate. The original implementation did
 * `MATCH ... DETACH DELETE n RETURN n`, which always returned null — a deleted
 * node cannot be returned — and destroyed the node's relationships along with
 * it. Flipping the status preserves every edge the proposal already has.
 */
async function approveProposal(slug, id, reviewerId, note) {
    const type = resolveType(slug);
    const session = getWriteSession();
    try {
        const result = await session.executeWrite((tx) => tx.run(`
            ${matchClause(type)} WHERE elementId(n) = $id
            SET n.status      = 'approved',
                n.approved_by = $reviewerId,
                n.approved_at = datetime(),
                n.review_note = $note
            REMOVE n.rejected_by, n.rejected_at, n.rejection_reason
            ${type.cascade || ''}
            RETURN ${proposalProjection(type)}
        `, { id, reviewerId, note: note || '' }));
        return result.records.length ? recordToObject(result.records[0]) : null;
    } finally {
        await session.close();
    }
}

/**
 * Reject, recording the reason.
 *
 * The artefact is kept with status 'rejected' rather than deleted. A submitter
 * who gets a silent rejection learns nothing and proposes the same thing again;
 * the reason is the only part of a rejection that has any value. It also keeps
 * the review trail exportable under §7.
 */
async function rejectProposal(slug, id, reviewerId, reason) {
    const type = resolveType(slug);
    const session = getWriteSession();
    try {
        const result = await session.executeWrite((tx) => tx.run(`
            ${matchClause(type)} WHERE elementId(n) = $id
            SET n.status           = 'rejected',
                n.rejected_by      = $reviewerId,
                n.rejected_at      = datetime(),
                n.rejection_reason = $reason
            ${type.cascade || ''}
            RETURN ${proposalProjection(type)}
        `, { id, reviewerId, reason }));
        return result.records.length ? recordToObject(result.records[0]) : null;
    } finally {
        await session.close();
    }
}

async function requestChanges(slug, id, reviewerId, reason) {
    const type = resolveType(slug);
    const session = getWriteSession();
    try {
        const result = await session.executeWrite((tx) => tx.run(`
            ${matchClause(type)} WHERE elementId(n) = $id
            SET n.status           = 'changes_requested',
                n.rejected_by      = $reviewerId,
                n.rejected_at      = datetime(),
                n.rejection_reason = $reason
            ${type.cascade || ''}
            RETURN ${proposalProjection(type)}
        `, { id, reviewerId, reason }));
        return result.records.length ? recordToObject(result.records[0]) : null;
    } finally {
        await session.close();
    }
}

/**
 * Withdraw one's own pending proposal.
 *
 * DETACH so a proposed Link takes its HAS_LINK edges with it; a relationship
 * proposal is deleted plainly, since there is nothing hanging off it. Ownership
 * and the pending status are both matched in the query rather than checked
 * beforehand, so there is no window between the check and the delete.
 */
async function deleteOwnProposal(slug, id, ownerId) {
    const type = resolveType(slug);
    const session = getWriteSession();
    try {
        const result = await session.executeWrite((tx) => tx.run(`
            ${matchClause(type)}
            WHERE elementId(n) = $id AND n.created_by = $ownerId AND n.status = 'pending'
            WITH ${carry(type)}, ${type.describe} AS item
            ${deleteClause(type)}
            ${type.deleteCascade || ''}
            RETURN item
        `, { id, ownerId }));
        return result.records.length ? result.records[0].get('item') : null;
    } finally {
        await session.close();
    }
}

module.exports = {
    PROPOSAL_TYPES,
    PROPOSAL_TYPE_SLUGS,
    RELATIONSHIP_TYPE_SLUGS,
    STATUSES,
    resolveType,
    findProposal,
    listProposals,
    approveProposal,
    rejectProposal,
    requestChanges,
    deleteOwnProposal,
};
