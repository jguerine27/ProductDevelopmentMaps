'use strict';

const config = require('../config');
const { AppError } = require('./errorHandler');
const { readSessionCookie, verifyToken, clearSessionCookie } = require('../services/session');
const { findUserById } = require('../services/users');

/**
 * The authorisation boundary.
 *
 * ── APPLY THESE AT THE ROUTER, NOT THE HANDLER ───────────────────────────────
 * Every write router mounts requireAuth (and requireReviewer where applicable)
 * with router.use() at the top of its parent, so a route added to that file
 * later inherits the guard. Guarding per handler means a new endpoint is
 * unprotected the moment somebody forgets one line, and that omission is
 * invisible in review. See routes/proposals/index.js and routes/manage/index.js.
 *
 * Every EXISTING read route stays public. The map is public; only writing needs
 * an account.
 */

const unauthorised = (message) => new AppError(401, 'AUTH_REQUIRED', message);
const forbidden = (code, message) => new AppError(403, code, message);

/**
 * Populate req.user when a valid session exists. Never rejects.
 *
 * Mounted app-wide, ahead of every router, so a public route can still tell who
 * is asking. The database is only touched when a session cookie is actually
 * present, so an anonymous read of the map costs nothing extra.
 *
 * THE ROLE IS READ HERE, FROM THE DATABASE, ON EVERY REQUEST — never taken from
 * the token. That is what makes PATCH /api/admin/users/:id/role take effect at
 * once rather than whenever the demoted reviewer's cookie happens to expire.
 */
async function attachUser(req, res, next) {
    try {
        const token = readSessionCookie(req);
        if (!token) return next();

        const payload = verifyToken(token);
        if (!payload) {
            // Forged, tampered or expired: clear it so the browser stops sending it.
            clearSessionCookie(res);
            return next();
        }

        const user = await findUserById(payload.uid);
        if (!user) {
            // The account is gone — DELETE /api/auth/me is the usual reason.
            // Erasure therefore revokes every session immediately.
            clearSessionCookie(res);
            return next();
        }

        // session_version is the bulk-revocation lever: bumping it on the node
        // invalidates every cookie already issued to this user.
        if (Number(payload.sv || 0) !== Number(user.session_version || 0)) {
            clearSessionCookie(res);
            return next();
        }

        req.user = {
            id: user.id,
            display_name: user.display_name,
            role: user.role,
            provider: user.provider,
            orcid: user.orcid,
        };
        return next();
    } catch (err) {
        // A database blip must not turn a public read into a 500.
        console.error('[auth] attachUser failed:', err.message);
        return next();
    }
}

function requireAuth(req, res, next) {
    if (!req.user) return next(unauthorised('Sign in to perform this action.'));
    return next();
}

function requireReviewer(req, res, next) {
    if (!req.user) return next(unauthorised('Sign in to perform this action.'));
    if (req.user.role !== 'reviewer') {
        return next(forbidden('FORBIDDEN_ROLE',
            'This action is restricted to peer reviewers. Reviewer access is granted by signing in with ORCID.'));
    }
    return next();
}

/**
 * Per-user write budget, held in memory.
 *
 * IT DOES NOT SURVIVE A RESTART AND DOES NOT SPAN REPLICAS. A restart resets
 * every counter, and two containers behind a load balancer would each allow the
 * full budget. That is an accepted trade at this scale — a research application
 * on a single container — and the alternative was a Redis dependency for a
 * problem the deployment does not have. If this ever runs replicated, this is
 * the thing to replace, not to tune.
 *
 * Keyed by AppUser.id, so it is only reachable behind requireAuth. Anonymous
 * traffic cannot write at all and therefore needs no bucket.
 */
const buckets = new Map();

function writeLimiter(req, res, next) {
    if (!req.user) return next();

    const now = Date.now();
    const windowMs = config.writeRateLimit.windowSeconds * 1000;
    const bucket = buckets.get(req.user.id);

    if (!bucket || now >= bucket.resetAt) {
        buckets.set(req.user.id, { count: 1, resetAt: now + windowMs });
        // Opportunistic sweep: without it the Map grows once per user forever.
        if (buckets.size > 1000) {
            for (const [key, value] of buckets) if (now >= value.resetAt) buckets.delete(key);
        }
        return next();
    }

    if (bucket.count >= config.writeRateLimit.maxWrites) {
        const retryAfter = Math.ceil((bucket.resetAt - now) / 1000);
        res.set('Retry-After', String(retryAfter));
        return next(new AppError(429, 'RATE_LIMITED',
            `Too many writes. Try again in ${retryAfter} second(s).`));
    }

    bucket.count += 1;
    return next();
}

/** Test hook — the counter is process-global, so suites must be able to clear it. */
function resetRateLimiter() {
    buckets.clear();
}

module.exports = { attachUser, requireAuth, requireReviewer, writeLimiter, resetRateLimiter };
